title: Java 算法 - 分治算法
date: '2019-09-14 13:43:34'
updated: '2019-09-14 13:43:34'
tags: [Java算法]
permalink: /articles/2019/09/14/1568439814414.html
---
![](https://img.hacpai.com/bing/20190209.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 分治算法

## 分治(Divide-and-Conquer(P))算法设计模式如下
```
if |P|≤n0
   then return(ADHOC(P))
//将P分解为较小的子问题 P1 ,P2 ,…,Pk
for i←1 to k
do yi ← Divide-and-Conquer(Pi)   递归解决Pi
T ← MERGE(y1,y2,…,yk)   合并子问题
return(T)
```
**其中|P|表示问题P的规模；n0为一阈值，表示当问题P的规模不超过n0时，问题已容易直接解出，不必再继续分解。ADHOC(P)是该分治法中的基本子算法，用于直接解小规模的问题P。因此，当P的规模不超过n0时直接用算法ADHOC(P)求解。算法MERGE(y1,y2,…,yk)是该分治法中的合并子算法，用于将P的子问题P1 ,P2 ,…,Pk的相应的解y1,y2,…,yk合并为P的解。**

# 实现案例
> **汉诺塔**
汉诺塔：汉诺塔（又称河内塔）问题是源于印度一个古老传说的益智玩具。大梵天创造世界的时候做了三根金刚石柱子，在一根柱子上从下往上按照大小顺序摞着64片黄金圆盘。大梵天命令婆罗门把圆盘从下面开始按大小顺序重新摆放在另一根柱子上。并且规定，在小圆盘上不能放大圆盘，在三根柱子之间一次只能移动一个圆盘。

## 汉诺塔思路分析
* 如果只有一个盘，直接将其移动到 C 盘 A -> C
* 如果有 n >= 2 个盘，我们总是可以看做是两个盘
  - 上面的 n - 1 个盘
  -  最下边的 1 个盘
* 先把最上边的盘从 A 盘 移动到 B 盘， A -> B
* 然后把最下边的那个盘从 A 盘移动到 C 盘 ， A -> C
* 把 B 塔 的所有盘从 B -> C

## 代码实现
```
/**
 * 汉诺塔问题
 * @Description
 * @Date 2019/9/9 19:12
 * @Author Aaron
 */
public class HanoiTower {
    static int count = 0;
    public static void main(String[] args) {
        hanoiTower(5, 'A', 'B', 'C');
        System.out.println("共移动 " + count + " 次");
    }

    /**
     * 汉诺塔的移动问题
     * 步骤如下 ->
     *         假设有 n 个盘子
     *      1. 如果 n = 1 ，则直接从 A -> C
     *      2. 如果 n >= 2, 我们总是可以拆分为两个盘
     *      3. 除最底下的上边的所有盘 2. 最下边的盘
     *         3.1 首先把最上边的 n - 1 个盘移动到 B 塔  A -> B
     *         3.2 再把最下边的 1 个盘移动到 C 塔        A -> C
     *         3.3 再把 B 塔的 n - 1 个盘移动到 C 塔      B -> C
     * @param num 表示有多少个盘子
     * @param a 塔 A
     * @param b 塔 B
     * @param c 塔 C
     */
    public static void hanoiTower(int num, char a, char b, char c) {
        count++;
        if (num == 1) {
            // 只有一个盘
            System.out.println("第1个盘从 " + a + "-> " + c);
        }else {
            // 把 n - 1 个盘移动到 B 塔, 此时需要借助 C 塔
            hanoiTower(num - 1, a, c, b);
            System.out.println("第" + num + "个盘从 " + a + "-> " + c);

            // 再把 B 塔的 n - 1 个盘移动到 C 塔
            hanoiTower(num -  1, b, a, c);
        }
    }
}
```

