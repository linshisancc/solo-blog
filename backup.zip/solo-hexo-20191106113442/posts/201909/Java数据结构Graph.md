title: Java 数据结构 - Graph
date: '2019-09-09 13:41:56'
updated: '2019-09-09 13:41:56'
tags: [Java数据结构]
permalink: /articles/2019/09/09/1568007716227.html
---
![](https://img.hacpai.com/bing/20181128.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 图

### 图的优势在哪

* 线性表局限于一个直接前驱和一个直接后继的关系
* 树也只能有一个直接前驱也就是父节点
* 当我们需要表示多对多的关系时， 这时我们就需要用到图

**图是一种数据结构，其中结点可以具有零个或多个相邻元素。两个结点之间的连接称为边。 结点也可以称为顶点。**
### 如下图

![image.png](https://img.hacpai.com/file/2019/09/image-05012623.png)
![image.png](https://img.hacpai.com/file/2019/09/image-53cb1ce5.png)

### 基本概念

![image.png](https://img.hacpai.com/file/2019/09/image-c06ecc45.png)

![image.png](https://img.hacpai.com/file/2019/09/image-cf96efdf.png)

### 图的表现方式

图的表示方式有两种：二维数组表示（邻接矩阵）；链表表示（邻接表）

### 邻接矩阵

邻接矩阵是表示图形中顶点之间相邻关系的矩阵，对于n个顶点的图而言，矩阵是的row和col表示的是1....n个点。(下图中的0代表不能直接连接，1代表能直接连接)

![image.png](https://img.hacpai.com/file/2019/09/image-6b056472.png)

### 邻接表
1. 邻接矩阵需要为每个顶点都分配n个边的空间，其实有很多边都是不存在,会造成空间的一定损失.
2. 邻接表的实现只关心存在的边，不关心不存在的边。因此没有空间浪费，邻接表由数组+链表组成

![image.png](https://img.hacpai.com/file/2019/09/image-ddb3e636.png)

**标号为0的结点的相关联的结点为 1 2 3 4, 标号为1的结点的相关联结点为0 4以此类推**

### 图的遍历

所谓图的遍历，即是对结点的访问。一个图有那么多个结点，如何遍历这些结点，需要特定策略，一般有两种访问策略: (1)深度优先遍历 (2)广度优先遍历

### 深度优先搜索(Depth First Search)
* 深度优先遍历，从初始访问结点出发，初始访问结点可能有多个邻接结点，深度优先遍历的策略就是首先访问第一个邻接结点，然后再以这个被访问的邻接结点作为初始结点，访问它的第一个邻接结点， 可以这样理解：每次都在访问完当前结点后首先访问当前结点的第一个邻接结点。
* 我们可以看到，这样的访问策略是优先往纵向挖掘深入，而不是对一个结点的所有邻接结点进行横向访问。
* 显然，深度优先搜索是一个递归的过程

>DFS算法步骤

1. 访问初始结点v，并标记结点v为已访问。
2. 查找结点v的第一个邻接结点w。
3. 若w存在，则继续执行4，如果w不存在，则回到第1步，将从v的下一个结点继续。
4. 若w未被访问，对w进行深度优先遍历递归（即把w当做另一个v，然后进行步骤123）。
5. 查找结点v的w邻接结点的下一个邻接结点，转到步骤3。


### 广度优先搜索(Broad First Search)
类似于一个分层搜索的过程，广度优先遍历需要使用一个队列以保持访问过的结点的顺序，以便按这个顺序来访问这些结点的邻接结点

>BFS算法步骤
1. 访问初始结点v并标记结点v为已访问。
2. 结点v入队列
3. 当队列非空时，继续执行，否则直接结束。
4. 出队列，取得队头结点u。
5. 查找结点u的第一个邻接结点w。
6. 若结点u的邻接结点w不存在，则转到步骤3；否则循环执行以下三个步骤：
  6.1 若结点w尚未被访问，则访问结点w并标记为已访问。 
  6.2 结点w入队列 
  6.3 查找结点u的继w邻接结点后的下一个邻接结点w，转到步骤6。

### 代码实现(用的邻接矩阵)

```
/**
 * 图
 * @Description
 * @Date 2019/9/9 10:34
 * @Author Aaron
 */
public class Graph {
    // 用来存放顶点
    private ArrayList<String> vertex;
    // 用矩阵表示图
    private int[][] graph;
    // 表示边
    private int edge;
    private boolean[] isVisited;

    // 初始化图
    public Graph(String[] vertexes) {
        if (vertexes == null || vertexes.length <= 0) throw new RuntimeException("图初始化失败");
        this.vertex = new ArrayList<>(vertexes.length);
        for (String s : vertexes) {
            vertex.add(s);
        }
        this.graph = new int[vertex.size()][vertex.size()];
        this.isVisited = new boolean[vertex.size()];
    }

    // 构建两个顶点之间的边线，如果通则为1不通则为0
    public void insertEdge(int a, int b, int weighted) {
        this.graph[a][b] = weighted;
        this.graph[b][a] = weighted;
    }

    /**
     * 从 index 所对应的顶点找到其后的第一个相通的顶点的下标并将其返回
     * 比如 index 等于 0 此时就是从 A 开始找到它的后第一个相通的顶点就是B, 对应的下标为 1
     * @param index 目标顶点所对应的下标
     * @return 返回-1 则没有找到否则直接返回对应顶点所在下标
     */
    public int getFirstVertexOfIndex(int index) {
        for (int i = 0; i < vertex.size(); i++) {
            if (graph[index][i] > 0) {
                // 找到第一个相通的顶点，将其下标返回
                return i;
            }
        }
        return -1;
    }

    /**
     * 返回两个相通顶点的下一个通顶点所在下标, 比如 A -> B - > C 都相通则返回C
     * @param v1 顶点1
     * @param v2 顶点2
     * @return
     */
    public int getNextVertexOfIndexByTwo(int v1, int v2) {
        for (int i = v2 + 1; i < vertex.size(); i++) {
            if (graph[v1][i] > 0) {
                return i;
            }
        }
        return -1;
    }

    // 重载广度优先遍历
    public void bfs() {
        isVisited = new boolean[vertex.size()];
        for (int i = 0; i < vertex.size(); i++) {
            if (!isVisited[i]) {
                bfs(i);
            }
        }
    }

    /**
     * 广度优先遍历
     * @param startIndex
     */
    public void bfs(int startIndex) {
        LinkedList<Integer> queue = new LinkedList<>();
        System.out.print(getValByIndex(startIndex));
        // 设置为已访问
        isVisited[startIndex] = true;
        // 将该顶点加入队列
        queue.addLast(startIndex);
        while (!queue.isEmpty()) {
            // 取出队列头顶点
            Integer first = queue.removeFirst();
            // 得到第一个相通的顶点
            int firstVertexOfIndex = getFirstVertexOfIndex(first);
            while (firstVertexOfIndex != -1) {
                // 是否访问过
                if (!isVisited[firstVertexOfIndex]){
                    System.out.print(getValByIndex(firstVertexOfIndex));
                    isVisited[firstVertexOfIndex] = true;
                    queue.addLast(firstVertexOfIndex);
                }
                firstVertexOfIndex = getNextVertexOfIndexByTwo(first, firstVertexOfIndex);
            }
        }
    }
    // 重载深度优先遍历
    public void dfs() {
        for (int i = 0; i < vertex.size(); i++) {
            if (!isVisited[i]) {
                dfs(i);
            }
        }
    }

    // 深度优先遍历
    public void dfs(int startIndex) {
        System.out.print(getValByIndex(startIndex));
        isVisited[startIndex] = true;
        int firstVertexOfIndex = getFirstVertexOfIndex(startIndex);
        while (true) {
            if (firstVertexOfIndex != -1) {
                // 该相通的顶点存在
                if (!isVisited[firstVertexOfIndex]) {
                    // 该顶点未被访问
                    dfs(firstVertexOfIndex);
                }else {
                    firstVertexOfIndex = getNextVertexOfIndexByTwo(startIndex, firstVertexOfIndex);
                }
            }else {

                return;
            }
        }
    }

    // 通过下标返回该顶点的值
    public String getValByIndex(int index) {
        return vertex.get(index);
    }

    // 显示图
    public void showGraph() {
        for (int[] cols : graph) {
            System.out.println(Arrays.toString(cols));
        }
    }
    
    public static void main(String[] args) {
        Graph graph = new Graph(new String[]{"1", "2", "3", "4", "5", "6", "7", "8"});
        // 这里我们用0代表A依次类推
        graph.insertEdge(0, 1, 1);
        graph.insertEdge(0, 2, 1);
        graph.insertEdge(1, 3, 1);
        graph.insertEdge(1, 4, 1);
        graph.insertEdge(3, 7, 1);
        graph.insertEdge(4, 7, 1);
        graph.insertEdge(2, 5, 1);
        graph.insertEdge(2, 6, 1);
        graph.insertEdge(5, 6, 1);
        // 显示图
        graph.showGraph();
        System.out.println("深度优先遍历###########");
        graph.dfs();
        System.out.println();
        System.out.println("广度优先遍历###########");
        graph.bfs();
    }
}
```
### 运行结果如下

![image.png](https://img.hacpai.com/file/2019/09/image-efda1551.png)


