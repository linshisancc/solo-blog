title: Java 数据结构 - stack
date: '2019-08-31 15:35:26'
updated: '2019-08-31 15:35:26'
tags: [Java数据结构]
permalink: /articles/2019/08/31/1567236926713.html
---
# 栈的应用场景有那些
* 子程序的调用，在跳往子程序前，会将下个指令的地址存到栈堆中，直到子程序执行完后再将地址取出，以回到原来的程序中
* 处理递归调用，和子程序有点类似，只是除了存储下个指令的地址外，也将参数，区域变量等数据存入堆栈中
* 表达式的转换`[中缀表达式转后缀表达式]`与求值(实际解决)
* 二叉树的遍历
* 图形的深度优先(deep-first)搜索法

代码实现:
```
/**
 * 用单链表实现栈
 * @Description TODO
 * @Date 2019/8/31 0031 14:07
 * @Author Aaron
 */
public class LinkedListStackDemo {
    public static void main(String[] args) {
        LinkedListStack linkedListStack = new LinkedListStack(5);
        linkedListStack.push(1);
        linkedListStack.push(2);
        linkedListStack.push(3);
        linkedListStack.push(4);
        linkedListStack.push(5);
        linkedListStack.list();
        linkedListStack.pop();
        linkedListStack.pop();
        linkedListStack.pop();
        linkedListStack.pop();
        linkedListStack.pop();
        System.out.println("#########################");
        linkedListStack.list();
        System.out.println("########################");
        linkedListStack.push(5);
        linkedListStack.push(6);
        linkedListStack.push(7);
        linkedListStack.push(8);
        linkedListStack.list();



    }
}

class LinkedListStack {
    // 创建一个头节点
    private StackNode head;
    private int maxCapacity;// 最大栈容量
    private int count; // 入栈的个数
    public LinkedListStack(int maxCapacity) {
        this.head = new StackNode(-1);
        this.maxCapacity = maxCapacity;
    }

    // 判断栈是否为空
    public boolean isEmpty() {
        return count == 0;
    }

    public void list() {
        if (isEmpty()) throw new RuntimeException("the stack is empty");
        reverseList(head.next);
    }

    // 出栈
    public void pop() {
        if (isEmpty()) throw new RuntimeException("the stack is empty");
        StackNode temp = head.next;
        //  移动到当前栈顶的前一位置 即移动 count - 2 次 直接将next 赋值为null 即出栈
        for (int i = 0; i < count - 2; i++) {
            temp = temp.next;
        }
        temp.next = null;
        count--;
    }

    /**
     * 使用逆序输出链表 模拟打印栈内容
     * @param stackNode
     */
    private void reverseList(StackNode stackNode) {
        if (stackNode == null) return;
        reverseList(stackNode.next);
        System.out.printf("val = %d \n", stackNode.val);
    }

    public boolean isFull() {
        return count == maxCapacity;
    }
    // 入栈
    public void push(int val) {
        if (isFull()) throw new RuntimeException("the stack is full");
        StackNode cur = new StackNode(val);
        StackNode temp = head;
        while (true) {
            if (temp.next == null) {
                // 到达链表尾部
                temp.next = cur;
                count++;
                break;
            }
            temp = temp.next;
        }
    }
}

// 创建节点
class StackNode {
    public int val;
    public StackNode next;

    public StackNode(int val) {
        this.val = val;
    }


}
```
