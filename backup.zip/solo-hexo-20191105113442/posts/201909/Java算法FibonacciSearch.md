title: Java 算法 - FibonacciSearch
date: '2019-09-04 13:29:24'
updated: '2019-09-04 13:29:24'
tags: [Java算法]
permalink: /articles/2019/09/04/1567574964730.html
---
![](https://img.hacpai.com/bing/20190324.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 斐波那契(黄金分割法)查找算法
* 黄金分割点是指把一条线段分割为两部分，使其中一部分与全长之比等于另一部分与这部分之比。取其前三位数字的近似值是0.618。由于按此比例设计的造型十分美丽，因此称为黄金分割，也称为中外比。这是一个神奇的数字，会带来意向不大的效果。
* 斐波那契数列 {1, 1, 2, 3, 5, 8, 13, 21, 34, 55 } 发现斐波那契数列的两个相邻数 的比例，无限接近 黄金分割值0.618

#### 原理

斐波那契查找原理与前两种相似，仅仅改变了中间结点（mid）的位置，mid不再是中间或插值得到，而是位于黄金分割点附近，即mid=low+F(k-1)-1（F代表斐波那契数列），如下图所示

![image.png](https://img.hacpai.com/file/2019/09/image-657c77d5.png)

#### 对F(k-1)-1的理解：
1. 由斐波那契数列 F[k]=F[k-1]+F[k-2] 的性质，可以得到 （F[k]-1）=（F[k-1]-1）+（F[k-2]-1）+1 。该式说明：只要顺序表的长度为F[k]-1，则可以将该表分成长度为F[k-1]-1和F[k-2]-1的两段，即如上图所示。从而中间位置为mid=low+F(k-1)-1 
2. 类似的，每一子段也可以用相同的方式分割
3. 但顺序表长度n不一定刚好等于F[k]-1，所以需要将原来的顺序表长度n增加至F[k]-1。这里的k值只要能使得F[k]-1恰好大于或等于n即可，由以下代码得到,顺序表长度增加后，新增的位置（从n+1到F[k]-1位置），都赋为n位置的值即可。
```
while(n > fib(k) - 1)
    k++;
```
下面直接来看我代码的思路

```
/**
 * 斐波那契查找
 * @Description TODO
 * @Date 2019/9/4 11:25
 * @Author Aaron
 */
public class FibonacciSearch {
    static int maxCapacity = 20;
    public static void main(String[] args) {
        int arr[] = {1, 8, 10, 89, 1000, 1234};
        int index = fibonacciSearch(arr, 1234);
        System.out.println("找到的下标为" + index);
    }

    /**
     * 斐波那契查找算法
     * @param arr 带查找目标数组
     * @param findVal 带查找的值
     * @return 返回对应值的下标
     */
    public static int fibonacciSearch(int arr[], int findVal) {
        int left = 0;
        int right = arr.length - 1;
        int k = 0;// 表示斐波那契数列的下标
        int mid = 0;
        int f[] = getFib();
        // 找到需要分割数的所在斐波那契数组中的下标k
        // 比如 right = 5
        //  f[] = {1, 1,  2,  3,  5,  8....}
        //  而 k 在斐波那契数列中需要移动到8 这个位置即下标为5 所以此时k 就等于5
        while (right > f[k] - 1) {
            k++;
        }
        // 然而此时arr的长度为6 而 f[k] = 8，所以我们需要拷贝一个新数组长度为 f[k]
        int temp[] = Arrays.copyOf(arr, f[k]);
        for (int i = right + 1; i < temp.length; i++) {
            // 将剩余的空元素补为arr数组的最后一个元素
            temp[i] = arr[right];
        }
        // 这个时候开始查找
        while (right >= left) {
            mid = left + f[k - 1] - 1;
            if (findVal > temp[mid]) {
                // 此时我们继续向 temp 的右边查找
                // 因为 f[k] = f[k - 1] + f[k - 2] -> f[k - 1] = f[k - 2] + f[k - 4]
                // 所以 k -= 2
                left = mid + 1;
                k -= 2;
            }else if (findVal < temp[mid]) {
                // 此时我们继续向 temp 的左边查找 同理可得 k -= 1
                right = mid - 1;
                k -= 1;
            }else {
                // 当找到值时，需要确定返回的是哪个下标，如果此时的mid已经大于right则返回right
                // 因为temp扩充的原因在原来arr的容量上把剩余的数已经填充为arr[right] 所以只需要返回right即可
                if (mid <= right) {
                    return mid;
                }else {
                    return right;
                }
            }
        }
        return -1;

    }

    // 获得一个斐波那契数列
    public static int[] getFib() {
        int fib[] = new int[maxCapacity];
        fib[0] = 1;
        fib[1] = 1;
        for (int i = 2; i < maxCapacity; i++) {
            fib[i] = fib[i - 1] + fib[i - 2];
        }
        return fib;
    }
}
```
