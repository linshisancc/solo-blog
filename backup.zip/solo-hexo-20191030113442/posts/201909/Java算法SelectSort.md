title: 'Java 算法 - SelectSort '
date: '2019-09-02 22:31:23'
updated: '2019-09-06 15:12:29'
tags: [Java算法]
permalink: /articles/2019/09/02/1567434683428.html
---
![](https://img.hacpai.com/bing/20181227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 选择排序法

#### 思想
选择排序（select sorting）也是一种简单的排序方法。它的基本思想是：第一次从arr[0] -> arr[n-1]中选取最小值，与arr[0]交换，第二次从arr[1] -> arr[n-1]中选取最小值，与arr[1]交换，第三次从arr[2] -> arr[n-1]中选取最小值，与arr[2]交换，…，第i次从arr[i-1] -> arr[n-1]中选取最小值，与arr[i-1]交换，…, 第n-1次从arr[n-2]  -> arr[n-1]中选取最小值，与arr[n-2]交换，总共通过n-1次，得到一个按排序码从小到大排列的有序序列。

#### 思路分析图

![image.png](https://img.hacpai.com/file/2019/09/image-32c8885f.png)

#### 

原始的数组为 : 

#### 代码实现


```
/**
 * 选择排序
 * @Description TODO
 * @Date 2019/9/2 21:50
 * @Author Aaron
 */
public class SelectSort {
    public static void main(String[] args) {
        int arr[] = {101, 34, 119, 1};
        selectSort(arr);
    }

    /**
     * 选择排序法
     * @param arr
     */
    public static void selectSort(int arr[]) {
        if (null == arr || arr.length <= 0) throw new RuntimeException("the array is empty");
        for (int i = 0; i < arr.length - 1; i++) {
            int minIndex = i;
            int min = arr[minIndex]; // 假设当前数为最小数
            for (int j = i + 1; j < arr.length; j++) {
                if (min > arr[j]) { //如果后一位数比当前数小
                    min = arr[j]; // 重置最小数和对应的下标
                    minIndex = j;
                }
            }
            if (minIndex != i) { // 如果走完该趟发现当前数就是最小值则不用换位
                arr[minIndex] = arr[i];
                arr[i] = min;
            }
            System.out.printf("第%d趟排序后的结果", i + 1);
            System.out.println(Arrays.toString(arr));
        }
    }
}
```

#### 过程解析

原始数组为 [101, 34, 119, 1]

第一轮排序后为 [1, 34, 119, 101]

第二轮排序后为 [1, 34, 119, 101]

第三轮排序后为 [1, 34, 101, 119]

**由此可以得出**

* 选排一共有 `arr.length - 1` 轮排序

* 每一轮排序又是一个循环，其规则如下
   - 先假设当前这个数为最小数
   - 然后和后面的每个数进行比较， 如果发现有比其更小的数，就重新确定最小数和下标
   - 当遍历到数组的最后时，就得到了本轮最小数和下标
   - 最后进行交换

**下面我们来测试下80000个数据用选择排序所花费的时间**

![image.png](https://img.hacpai.com/file/2019/09/image-d84a28c6.png)

差不多3秒，是冒泡排序的4倍快 😰
     
