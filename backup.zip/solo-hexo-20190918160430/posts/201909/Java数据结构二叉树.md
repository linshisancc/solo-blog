title: Java 数据结构 - 二叉树
date: '2019-09-05 12:36:57'
updated: '2019-09-05 12:36:57'
tags: [Java数据结构]
permalink: /articles/2019/09/05/1567658217320.html
---
![](https://img.hacpai.com/bing/20190423.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 二叉树
#### 为什么需要树这种数据结构
* 数组存储方式的分析
  - 优点：通过下标方式访问元素，速度快。对于有序数组，还可使用二分查找提高检索速度。
  - 缺点：如果要检索具体某个值，或者插入值(按一定顺序)会整体移动，效率较低
* 链式存储方式的分析
  - 优点：在一定程度上对数组存储方式有优化(比如：插入一个数值节点，只需要将插入节点，链接到链表中即可， 删除效率也很好)。
  - 缺点：在进行检索时，效率仍然较低，比如(检索某个值，需要从头节点开始遍历) 

#### 示意图

![image.png](https://img.hacpai.com/file/2019/09/image-9a98b6b0.png)


> 树的常用术语(结合示意图理解):
节点
根节点
父节点
子节点
叶子节点 (没有子节点的节点)
节点的权(节点值)
路径(从root节点找到该节点的路线)
层
子树
树的高度(最大层数)
森林 :多颗子树构成森林
树的常用术语(结合示意图理解):
节点
根节点
父节点
子节点
叶子节点 (没有子节点的节点)
节点的权(节点值)
路径(从root节点找到该节点的路线)
层
子树
树的高度(最大层数)
森林 :多颗子树构成森林

#### 二叉树的概念

* 树有很多种，每个节点最多只能有两个子节点的一种形式称为二叉树
* 二叉树的子节点分为左节点和右节点。

![image.png](https://img.hacpai.com/file/2019/09/image-a0bbf0c5.png)

* 如果该二叉树的所有叶子节点都在最后一层，并且结点总数= 2^n -1 , n 为层数，则我们称为满二叉树。
* 如果该二叉树的所有叶子节点都在最后一层或者倒数第二层，而且最后一层的叶子节点在左边连续，倒数第二层的叶子节点在右边连续，我们称为完全二叉树。

![image.png](https://img.hacpai.com/file/2019/09/image-d1032426.png)

![image.png](https://img.hacpai.com/file/2019/09/image-29e01c9c.png) 
**如果把61删除就不是完全二叉树了，因为叶子节点不连续了**

#### 二叉树遍历
1. 前序遍历: 先输出父节点，再遍历左子树和右子树
2. 中序遍历: 先遍历左子树，再输出父节点，再遍历右子树
3. 后序遍历: 先遍历左子树，再遍历右子树，最后输出父节点

**看输出父节点的顺序，就确定是前序，中序还是后序**

下面二叉树的查找，与删除功能我将在代码里展示

```
/**
 * 二叉树
 * @Description TODO
 * @Date 2019/9/4  20:54
 * @Author Aaron
 */
public class BinaryTreeDemo {
    public static void main(String[] args) {
        BinaryTree binaryTree = new BinaryTree();
        TreeNode root = new TreeNode(1, "张三");
        TreeNode node1 = new TreeNode(2, "李四");
        TreeNode node2 = new TreeNode(3, "王五");
        TreeNode node3 = new TreeNode(4, "李蛋");
        TreeNode node4 = new TreeNode(5, "小白");
        TreeNode node5 = new TreeNode(6, "小红");
        TreeNode node6 = new TreeNode(7, "小张");
        root.setLeft(node1);
        root.setRight(node2);
        node1.setLeft(node5);
        node1.setRight(node6);
        node2.setRight(node3);
        node2.setLeft(node4);
        binaryTree.setRoot(root);

        //System.out.println("测试前序遍历");
        //binaryTree.preOrder();

        //System.out.println("测试中序遍历");
        //binaryTree.midOrder();

        //System.out.println("测试后序遍历");
        //binaryTree.postOrder();
          binaryTree.delNode(2);
          binaryTree.preOrder();
        //System.out.println(treeNode);
    }
}

// 二叉树
class BinaryTree {
    private TreeNode root;

    public void setRoot(TreeNode root) {
        this.root = root;
    }

    // 前序遍历
    public void preOrder() {
        if (root != null) {
            this.root.preOrder();
        }
    }

    // 中序遍历
    public void midOrder() {
        if (root != null) {
            this.root.midOrder();
        }
    }

    // 后序遍历
    public void postOrder() {
        if (root != null) {
            this.root.postOrder();
        }
    }

    // 前序遍历查找
    public TreeNode preOrderSearch(int id) {
        if (root != null) {
            return root.preOrderSearch(id);
        }else {
            return null;
        }
    }

    // 中序遍历查找
    public TreeNode midOrderSearch(int id) {
        if (root != null) {
            return root.midOrderSearch(id);
        }else {
            return null;
        }
    }
    
    // 后序遍历查找
    public TreeNode postOrderSearch(int id) {
        if (root != null) {
            return root.postOrderSearch(id);
        }else {
            return null;
        }
    }

    public void delNode(int no) {
        if (root != null && root.getId() != no) {
            root.delNode(no);
        }else {
            root = null;
        }
    }
}
/**
 * 树节点
 */
class TreeNode {
    private int id;
    private String name;
    private TreeNode left;
    private TreeNode right;

    public TreeNode(int id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * 如果要删除的节点是非叶子节点，我们不能将以该非叶子节点为根的子树删除
     * 如果该非叶子节点只有一个子节点，则直接让该子节点替代该非叶子节点
     * 如果该非叶子节点有两个子节点，则让左子节点替代该非叶子节点
     * @param id
     */
    public void delNode(int id) {
        TreeNode treeNode = null;
        
        // 如果当前节点的左子节点不为空，并且左子节点就是要删除节点, 此时要判断该左子节点是不是叶子节点
        if (this.left != null && this.left.id == id) {
            if (this.left.left != null && this.left.right == null) {
                // 表示当前节点为非叶子节点并且只有一个左子节点，此时我们直接让左子节点替代该非叶子节点
                this.left = this.left.left;
            }else if (this.left.left == null && this.left.right != null) {
                // 表示当前节点为非叶子节点并且只有一个右子节点，此时我们直接让该右子节点替代该非叶子节点
                this.left = this.left.right;
            }else if (this.left.left != null && this.left.right != null) {
                // 表示当前节点为非叶子节点并且有两个子节点, 此时我们让左子节点替代该非叶子节点，并让右子节点成为替代后的非叶子节的的左子节点
                TreeNode cur = this.left;
                TreeNode curR = this.left.right;
                this.left = this.left.left;
                cur.left.right = curR;
            }else {
                // 表示当前节点为叶子节点，直接让其父节点的left置空即可
                this.left = null;
            }
        }

        // 如果当前节点的右子节点不为空，并且右子节点就是要删除节点，此时要判断该右子节点是不是叶子节点
        if (this.right != null && this.right.id == id) {
            // 如果要删除的是非叶子节点, 则让该节点的子节点替代该节点
            if (this.right.left != null && this.right.right == null) {
                // 以下同理, 只是换了一边
                this.right = this.right.left;
            }else if (this.right.left == null && this.right.right != null) {
                this.right = this.right.right;
            }else if (this.right.left != null && this.right.right != null) {
                TreeNode cur = this.right;
                TreeNode curR = this.right.right;
                this.right = this.right.left;
                cur.left.right = curR;
            }else {
                this.right = null;
            }
        }

        // 向左子树进行递归删除
        if (this.left != null) {
            this.left.delNode(id);
        }

        // 向右子树进行递归删除
        if (this.right != null) {
            this.right.delNode(id);
        }
    }


    // 前序遍历查找
    public TreeNode preOrderSearch(int id) {
        System.out.println("前序遍历查找");
        // 先判断当前节点是不是要查找的节点
        if (this.id == id) {
            return this;
        }
        TreeNode treeNode = null;
        // 判断当前节点的左子节点是否为空，如果不为空则递归查找
        if (this.left != null) {
            treeNode = this.left.preOrderSearch(id);
        }

        // 如果treeNode 不为空说明在左子树中找到 直接返回
        if (treeNode != null) {
            return treeNode;
        }
        // 判断当前节点的右子节点是否为空，如果不为空则递归查找
        if (this.right != null) {
            treeNode = this.right.preOrderSearch(id);
        }
        return treeNode;

    }

    // 中序遍历查找
    public TreeNode midOrderSearch(int id) {
        TreeNode treeNode = null;
        // 先判断当前节点的左子节点是否为空，如果不为空则递归查找
        if (this.left != null) {
            treeNode = this.left.midOrderSearch(id);
        }
        if (treeNode != null) {
            return treeNode;
        }
        System.out.println("中遍历查找");
        // 如果向左子节点递归的过程找到了就返回，没有找到就和当前节点比较
        if (this.id == id) {
            return this;
        }

        if (this.right != null) {
            treeNode = this.right.midOrderSearch(id);
        }
        return treeNode;
    }

    // 后序遍历查找
    public TreeNode postOrderSearch(int id) {
        TreeNode treeNode = null;
        // 先判断当前节点的左子节点是否为空，如果不为空则递归查找
        if (this.left != null) {
            treeNode = this.left.postOrderSearch(id);
        }
        // 说明左子树种找到
        if (treeNode != null) {
            return treeNode;
        }

        // 如果左子树没找到，则向右子树递归查找
        if (this.right != null) {
            treeNode = this.right.postOrderSearch(id);
        }
        if (treeNode != null) {
            return treeNode;
        }
        System.out.println("后序遍历查找");
        // 如果右子树也没有找到，就比较当前节点
        if (this.id == id) {
            return this;
        }
        return treeNode;
    }


    // 前序遍历
    public void preOrder() {
        System.out.println(this);
        if (this.left != null) {
            this.left.preOrder();
        }
        if (this.right != null) {
            this.right.preOrder();
        }
    }

    // 中序遍历
    public void midOrder() {
        if (this.left != null) {
            this.left.midOrder();
        }
        System.out.println(this);
        if (this.right != null) {
            this.right.midOrder();
        }
    }

    // 后序遍历
    public void postOrder() {
        if (this.left != null) {
            this.left.postOrder();
        }

        if (this.right != null) {
            this.right.postOrder();
        }
        System.out.println(this);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TreeNode getLeft() {
        return left;
    }

    public void setLeft(TreeNode left) {
        this.left = left;
    }

    public TreeNode getRight() {
        return right;
    }

    public void setRight(TreeNode right) {
        this.right = right;
    }

    @Override
    public String toString() {
        return "TreeNode{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
```



