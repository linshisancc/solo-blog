title: Java 算法 - BubbleSort
date: '2019-09-02 21:11:53'
updated: '2019-09-02 21:13:06'
tags: [Java算法]
permalink: /articles/2019/09/02/1567429913484.html
---
![](https://img.hacpai.com/bing/20181227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 冒泡排序
* 冒泡排序（Bubble Sorting）的基本思想是：通过对待排序序列从前向后（从下标较小的元素开始）,依次比较
相邻元素的值，若发现逆序则交换，使值较大的元素逐渐从前移向后部，就象水底下的气泡一样逐渐
向上冒。
* 因为排序的过程中，各元素不断接近自己的位置，如果一趟比较下来没有进行过交换，就说明序列有序，因此要在排序过程中设置一个标志flag判断元素是否进行过交换。从而减少不必要的比较。(这里说的优化，可以在冒泡排序写好后，在进行)

## 代码实现
```
/**
 * 冒泡排序 时间复杂度为 O(n^2)
 * @Description TODO
 * @Date 2019/9/2 20:37
 * @Author Aaron
 */
public class BubbleSort {
    public static void main(String[] args) {
        int arr[] = {3, 9, -1, 10, 20};

        //下面我来测试下 80000个数据用冒泡排序所花费的时间
        //int arr[] = new int[80000];//产生80000个 1 - 8000000 的随机数
        //for (int i = 0; i < arr.length; i++) {
        //    arr[i] = (int) (Math.random() * 8000000);
        //}
        //long start = System.currentTimeMillis();// 获取当前系统的毫秒数
        bubbleSort(arr);
        //long end = System.currentTimeMillis();
        //System.out.printf("80000个随机数据排序所花费毫秒数为: %d 毫秒", end - start);
    }

    /**
     * 冒泡排序 时间复杂度为 O(n^2)
     * @param arr
     */
    public static void bubbleSort(int arr[]) {
        if (null == arr || arr.length <0 ) throw new RuntimeException("the array is empty");
        int temp = 0;// 创建一个临时变量用于交换
        boolean flag = false;// 创建一个标示符代表是否进行过交换

        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    flag = true;
                }
            }

            // 如果一趟排序下来没有元素进行交换则认为排序完毕
            if (!flag) {
                break;
            }else {
                flag = false;
            }
            System.out.printf("第%d趟排序后的结果", i + 1);
            System.out.println(Arrays.toString(arr));
        }
    }
}
```
**此时我们可以看到结果如下**

![image.png](https://img.hacpai.com/file/2019/09/image-accf1c6b.png)

**下面我来测试下 80000个随机数用冒泡排序所花费的时间**

```
int arr[] = new int[80000];//产生80000个 1 - 8000000 的随机数
for (int i = 0; i < arr.length; i++) {
	arr[i] = (int) (Math.random() * 8000000);
}
long start = System.currentTimeMillis();// 获取当前系统的毫秒数
bubbleSort(arr);
long end = System.currentTimeMillis();
System.out.printf("80000个随机数据排序所花费毫秒数为: %d 毫秒", end - start);
```
结果如下

![image.png](https://img.hacpai.com/file/2019/09/image-9c2489d2.png)

试了几次大概就是13秒左右，这和你的计算机硬件也有一定关系配置够高计算越快....
