title: Java 数据结构 - Queue
date: '2019-08-29 13:07:10'
updated: '2019-08-29 14:32:54'
tags: [Java数据结构]
permalink: /articles/2019/08/29/1566997684912.html
---
![3gaitubao1920x1070.jpg](https://img.hacpai.com/file/2019/08/3gaitubao1920x1070-85eaaaaa.jpg)

# 循环队列

**循环队列示意图**

![201982910031.png](https://img.hacpai.com/file/2019/08/201982910031-fc4166b5.png)

从上图我们可以看出 `front` 指向队列中第一个元素，`rear` 指向队列队尾的下一个位置。

#### 问题：当`front`和`rear`指向同一个位置时，这代表的是队空还是队满呢？

#### 解决 : 牺牲一个元素空间。当front和rear相等时，为空；当rear的下一个位置是front时，为满。

如下图:

![20150623125730736.png](https://img.hacpai.com/file/2019/08/20150623125730736-3a290b49.png)  ![20150623125754160.png](https://img.hacpai.com/file/2019/08/20150623125754160-adbc3935.png)

话不多说, 直接上代码 :

#### 方法1
```
/**
 * 环形队列
 * @Author Aaron
 */
public class CircleArrayQueueDemo {
    public static void main(String[] args) {
        CircleArrayQueue queue = new CircleArrayQueue(4);
        queue.addToQueue(10);
        queue.addToQueue(20);
        queue.addToQueue(30);
        queue.pop();
        queue.pop();
        queue.pop();
        queue.addToQueue(50);
        queue.addToQueue(60);
        queue.addToQueue(70);
        queue.show();
        queue.pop();
    }
}

// 环形队列
class CircleArrayQueue {

    private int[] queue;// 用来存储数据的队列
    private int front;// 指向队列头
    private int rear; // 指向队列尾的后一个位置 腾出一块空间 用来判断队列是否满
    private int maxCapacity; // 队列的最大容量
    public static final String EMPTY_EXCEPTION = "the queue is empty";
    public static final String FULL_EXCEPTION = "the queue is full";

    public CircleArrayQueue(int maxCapacity) {
        this.maxCapacity = maxCapacity;
        queue = new int[maxCapacity];
    }

    // 判断队列是否满
    public boolean isFull() {
        return (rear + 1) % maxCapacity == front;
    }

    // 判断队列是否为空
    public boolean isEmpty() {
        return front == rear;
    }

    // 添加数据到队列中
    public void addToQueue(int value) {
        if (isFull()) throw new RuntimeException(FULL_EXCEPTION);
        queue[rear] = value;
        rear = (rear + 1) % maxCapacity;
    }

    // 出队
    public int pop() {
        if (isEmpty()) throw new RuntimeException(EMPTY_EXCEPTION);
        int temp = queue[front];
        front = (front + 1) % maxCapacity;
        return temp;
    }

    // 查看队列头的数据
    public int peek() {
        if (isEmpty()) throw new RuntimeException(EMPTY_EXCEPTION);
        return queue[front];
    }

    public void show() {
        if (isEmpty()) throw new RuntimeException(EMPTY_EXCEPTION);
        // 从 front 开始遍历 遍历 （rear + maxSize - front）% maxCapacity 个有效元素
        for (int i = front; i < front + size(); i++) {
            System.out.printf("queue[%d] = %d\n", i % maxCapacity, queue[i % maxCapacity]);
        }
    }

    // 返回当前队列中的有效元素的个数
    public int size() {
        return (rear + maxCapacity - front) % maxCapacity;
    }
}

```
#### 方法2

```
package com.linshisan.datastructure;

/**
 * 数组实现循环队列
 * @Author Aaron
 */
public class ArrayQueueDemo {
    public static void main(String[] args) {
        Queue queue = new Queue(4);
        queue.addToQueue(1);
        queue.addToQueue(2);
        queue.addToQueue(3);
        queue.addToQueue(4);
        //   0    1   2   3
        // front
        //                 rear
        queue.show();
        queue.pop();
        queue.pop();
        queue.pop();
        queue.pop();
        //  0   1   2     3
        //               front
        //               rear
        // 此时 front == rear 重置指针,把 front 指针指向 0 rear 指针指向 1
        //  0    1   2    3
        // front
        //      rear
        queue.addToQueue(5);
        queue.addToQueue(6);
        queue.addToQueue(7);
        queue.addToQueue(8);
        queue.show();
        System.out.println(queue.peek());
    }
}

class Queue {
    private int[] queue;// 用来存储数据的队列
    private int front;// 队列头
    private int rear; // 队列尾部
    private int maxCapacity; // 队列的最大容量
    private int size;// 队列有效元素个数
    public static final String EMPTY_EXCEPTION = "the queue is empty";
    public static final String FULL_EXCEPTION = "the queue is full";
    public Queue(int maxCapacity) {
        this.maxCapacity = maxCapacity;
        this.queue = new int[maxCapacity];
        this.front = 0; // 指向队列头
        this.rear = 0; // 指向队列队尾
    }

    // 判断队列是否满
    public boolean isFull() {
        // 当有效元素大于或等于最大容量是则队列为满
        return size >= maxCapacity;
    }

    // 判断队列是否为空
    public boolean isEmpty() {
        return front == rear;
    }

    // 添加数据到队列中
    public void addToQueue(int value) {
        if (isFull()) throw new RuntimeException(FULL_EXCEPTION);
        if (isEmpty()) { // 重置头尾指针
            front = 0;
            queue[front] = value;
            rear = 1;
        }else {
            queue[rear++] = value;
        }
        size++;
    }

    // 删除队列头的数据
    public int pop() {
        if (isEmpty()) throw new RuntimeException(EMPTY_EXCEPTION);
        int temp = queue[front++];
        size--;
        return temp;
    }

    // 查看队列头的数据
    public int peek() {
        if (isEmpty()) throw new RuntimeException(EMPTY_EXCEPTION);
        return queue[front];
    }
    
    public void show() {
        if (isEmpty()) throw new RuntimeException(EMPTY_EXCEPTION);
        for (int i = 0; i < queue.length; i++) {
            System.out.printf("queue[%d] = %d\n", i, queue[i]);
        }
    }
}
```
