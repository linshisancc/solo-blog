title: Java 算法 - InsertSort
date: '2019-09-03 11:20:34'
updated: '2019-09-03 11:20:55'
tags: [Java算法]
permalink: /articles/2019/09/03/1567480834059.html
---
![](https://img.hacpai.com/bing/20190524.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 插入排序法
插入式排序属于内部排序法，是对于欲排序的元素以插入的方式找寻该元素的适当位置，以达到排序的目的。

#### 思想
插入排序（Insertion Sorting）的基本思想是：把n个待排序的元素看成为一个有序表和一个无序表，开始时有序表中只包含一个元素，无序表中包含有n-1个元素，排序过程中每次从无序表中取出第一个元素，把它的排序码依次与有序表元素的排序码进行比较，将它插入到有序表中的适当位置，使之成为新的有序表。

**图例**

![image.png](https://img.hacpai.com/file/2019/09/image-2458f956.png)

代码

```
/**
 * 插入排序法
 * @Description TODO
 * @Date 2019/9/2 23:20
 * @Author Aaron
 */
public class InsertSort {
    public static void main(String[] args) {
        //int arr[] = {101, 34, 119, 1};
        int arr[] = new int[80000];
        SelectSort.getArr(arr);
        long start = System.currentTimeMillis();// 获取当前系统的毫秒数
        insertSort(arr);
        long end = System.currentTimeMillis();
        System.out.printf("80000个随机数使用插入排序所花费毫秒数为: %d 毫秒", end - start);

    }

    public static void insertSort(int arr[]) {
        if (null == arr || arr.length <= 0) throw new RuntimeException("the array is empty");
        for (int i = 1; i < arr.length; i++) {
            // 待插入数
            int insertVal = arr[i];
            int insertIndex = i - 1; // arr[i] 这个数的前一个数的下标
            // insertIndex >= 0 保证不越界
            for (int j = i; j > insertIndex; j--) {
                if (insertIndex >= 0 && insertVal < arr[insertIndex]) { 
	            // 表示待插入的数还没有找到插入位置
                    arr[insertIndex + 1] = arr[insertIndex];// 此时将arr[insertIndex] 后移
                    insertIndex--;
                }
            }
            arr[insertIndex + 1] = insertVal;
        }
    }
}

```

此时我们也比较了将80000个数据进行排序后的时间花销

![image.png](https://img.hacpai.com/file/2019/09/image-99c5fecd.png)

看似挺快的，实际上还存在一个问题，

比如数组 arr = {2,3,4,5,6,1} 这时需要插入的数 1(最小), 这样的过程是：
```
{2,3,4,5,6,6}
{2,3,4,5,5,6}
{2,3,4,4,5,6}
{2,3,3,4,5,6}
{2,2,3,4,5,6}
{1,2,3,4,5,6}
```
很明显当需要插入的数是较小的数时，后移的次数明显增多，影响了效率，后续还能够进行优化。
