title: Java 数据结构 - AVLTree
date: '2019-09-08 13:34:25'
updated: '2019-09-08 14:01:27'
tags: [Java数据结构]
permalink: /articles/2019/09/08/1567920865244.html
---
![](https://img.hacpai.com/bing/20190728.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 平衡二叉树(AVL树)

### 为什么会有平衡二叉树，是因为排序二叉树可能会遇到一个问题，看下图
### 给你一个数列{1,2,3,4,5,6}，要求创建一颗二叉排序树(BST), 并分析问题所在

![123123124141.PNG](https://img.hacpai.com/file/2019/09/123123124141-3814cc95.PNG)

### 这颗BST存在什么问题呢
* 左子树全部为空，从形式上看，更像一个单链表
* 插入速度没有影响
* 查询速度明显降低(因为需要依次比较), 不能发挥BST的优势，因为每次还需要比较左子树，其查询速度比单链表还慢
* 此时就用到了我们的解决方案-平衡二叉树(AVL)

### 基本介绍
* 平衡二叉树也叫平衡二叉搜索树（Self-balancing binary search tree）又被称为AVL树， 可以保证查询效率较高。
* 具有以下特点：它是一 棵空树或它的左右两个子树的高度差的绝对值不超过1，并且左右两个子树都是一棵平衡二叉树。平衡二叉树的常用实现方法有红黑树、AVL、替罪羊树、Treap、伸展树等。

![image.png](https://img.hacpai.com/file/2019/09/image-b932ec4e.png)![image.png](https://img.hacpai.com/file/2019/09/image-088427f8.png)![image.png](https://img.hacpai.com/file/2019/09/image-d5e04a61.png)

### 从上面三个我们可以看出树1和树2是满足平衡二叉树的要求的，而树3不满足

### 左旋转

![左旋转.gif](https://img.hacpai.com/file/2019/09/左旋转-82a2002a.gif)


给定一个数列 {4,3,6,5,7,8}, 要求创建对应的AVL树

### 首先我们需要一个获得以该节点为根节点的树的高度的方法
```
// 返回以该结点为根结点的树的高度
    public int getHeight() {
       return Math.max(this.left == null ? 0 : this.left.getHeight(), this.right == null ? 0 : this.right.getHeight()) + 1;
    }
```
### 然后还需要以该节点为根节点的左右子树的高度的方法

```
// 返回该结点的左子树的高度
    public int leftHeight() {
        if (this.left != null) {
            return this.left.getHeight();
        }
        return 0;
    }
    // 返回该结点的右子树的高度
    public int rightHeight() {
        if (this.right != null) {
            return this.right.getHeight();
        }
        return 0;
    }
```

```
// 左旋转
    public void leftRotate() {
        // 创建一个新结点，值等于当前节点的值
        Node newNode = new Node(this.val);
        // 新结点的左子树指向当前节点的左子树
        newNode.left = this.left;
        // 新结点的右子树指向当前节点的右子树的左子树
        newNode.right = this.right.left;
        // 当前节点的值赋值为右子树的值
        this.val = this.right.val;
        // 当前节点的右子树指向当前节点的右子树的右子树
        this.right = this.right.right;
        // 当前节点的左子树指向新结点
        this.left = newNode;
    }
```

### 此时如果满足`this.rightHeight() - this.leftHeight() > 1` 就进行左旋

### 右旋转
![右旋转动画.gif](https://img.hacpai.com/file/2019/09/右旋转动画-39179653.gif)


给定一个数列 {10,12, 8, 9, 7, 6}, 创建对应的AVL树

```
// 右旋转
    public void rightRotate() {
        Node newNode = new Node(this.val);
        newNode.right = this.right;
        newNode.left = this.left.right;
        this.val = this.left.val;
        this.left = this.left.left;
        this.right = newNode;
    }
```

### 如果满足`this.leftHeight() - this.rightHeight() > 1` 就进行右旋

### 双旋转

在前面两个数列中，进行单旋转就可以将非平衡二叉树转为平衡二叉树，但是在某种情况下，单旋转不能完成转换

给定两个数列 arr1 = { 10, 11, 7, 6, 8, 9 }, arr2 = {2,1,6,5,7,3}, 只进行单旋转，发现并没有效果，此时我们只需要将添加节点时的判断代码修改一下即可

### 代码如下

```
/**
     * 使用递归添加节节点，满足二叉排序树的要求
     * @param node
     */
    public void add(Node node) {
        if (node == null) return;

        // 判断当前传入的节点的值，和当前子树的根节点的值的关系
        if (this.val > node.val) {
            // 如果当前节点的左子节点为null
            if (this.left == null) {
                this.left = node;
            }else {
                this.left.add(node);
            }
        }else {
            // 表示添加的节点的值大于当前节点的值
            if (this.right == null) {
                this.right = node;
            }else {
                this.right.add(node);
            }
        }

        // 每添加完一个结点，需要判断当前节点的左子树高度与右子树高度差是否大于1,在来进行旋转
        int len = this.rightHeight() - this.leftHeight();
        if (len > 1) {
            // 考虑双旋转问题
            if (this.right != null && this.right.leftHeight() > this.right.rightHeight()) {
                //先将右子节点 进行右旋
                this.right.rightRotate();
                // 在将当前节点进行左旋
                this.leftRotate();
            }else {
                this.leftRotate();
            }
        }else if (len < -1) {
            // 以上同理
            if (this.left != null && this.left.rightHeight() > this.left.leftHeight()) {
                this.left.leftRotate();
                this.rightRotate();
            }else {
                this.rightRotate();
            }
        }else {
            // 不需要旋转,二叉树已经是平衡的
            return;
        }
    }
```

### 为什么会存在这种情况，我们来看图分析

![asdnnnqwe.PNG](https://img.hacpai.com/file/2019/09/asdnnnqwe-f572a183.PNG)

#### 我们可以发现，右旋转过后，它还是一个非平衡二叉树
所以在满足右旋转的时候我们需要加一个条件
1. 如果当前结点的左子树的右子树的高度大于当前节点的左子树的左子树高度
2. 就需要对以当前节点为根结点的左子树先进行左旋转
3. 然后在将当前节点右旋转即可
4. 否则我们就直接对当前结点进行右旋转

![20191108883.PNG](https://img.hacpai.com/file/2019/09/20191108883-22429337.PNG)


#### 同理左旋转也要加一个条件
1. 如果当前结点的右子树的左子树的高度大于当前节点的右子树的右子树高度
2. 就需要对以当前节点为根节点的右子树先进行右旋转
3. 然后再将当前结点左旋转
4. 否则直接对当前节点进行左旋转

### 代码实现

```
/**
     * 使用递归添加节节点，满足二叉排序树的要求
     * @param node
     */
    public void add(Node node) {
        if (node == null) return;

        // 判断当前传入的节点的值，和当前子树的根节点的值的关系
        if (this.val > node.val) {
            // 如果当前节点的左子节点为null
            if (this.left == null) {
                this.left = node;
            }else {
                this.left.add(node);
            }
        }else {
            // 表示添加的节点的值大于当前节点的值
            if (this.right == null) {
                this.right = node;
            }else {
                this.right.add(node);
            }
        }

        // 每添加完一个结点，需要判断当前节点的左子树高度与右子树高度差是否大于1,在来进行旋转
        int len = this.rightHeight() - this.leftHeight();
        if (len > 1) {
            // 考虑双旋转问题
            if (this.right != null && this.right.leftHeight() > this.right.rightHeight()) {
                //先将右子节点 进行右旋
                this.right.rightRotate();
                // 在将当前节点进行左旋
                this.leftRotate();
            }else {
                this.leftRotate();
            }
        }else if (len < -1) {
            // 以上同理
            if (this.left != null && this.left.rightHeight() > this.left.leftHeight()) {
                this.left.leftRotate();
                this.rightRotate();
            }else {
                this.rightRotate();
            }
        }else {
            // 不需要旋转,二叉树已经是平衡的
            return;
        }
    }
```


### 完整代码

```
/**
 * 平衡二叉树
 * @Description TODO
 * @Date 2019/9/8 11:18
 * @Author Aaron
 */
public class AVLTreeDemo {
    public static void main(String[] args) {
//        int arr[] = {4, 3, 6, 5, 7, 8};
//        int arr[] = {10, 12, 8, 9, 7, 6};
          int arr[] = {2,1,6,5,7,3};

        AVLTree avlTree = new AVLTree();
        for (int i : arr) {
            avlTree.add(new Node(i));
        }
        System.out.println("平衡后的二叉树");
        System.out.println("结点的高度" + avlTree.root.getHeight());
        System.out.println("结点的左子树高度" + avlTree.root.left.getHeight());
        System.out.println("结点的右子树高度" + avlTree.root.right.getHeight());
        System.out.println(avlTree.root);
    }
}

class AVLTree {
    public Node root;

    // 中序遍历
    public void infixOrder() {
        if (root != null) {
            root.infixOrder();
        }else {
            System.out.println("树为空，遍历失败");
        }
    }



    public void add(Node node) {
        if (root == null) {
            root = node;
        }else {
            root.add(node);
        }
    }
}

class Node {
    public int val;
    public Node left;
    public Node right;

    public Node(int val) {
        this.val = val;
    }

    // 返回以该结点为根结点的树的高度
    public int getHeight() {
       return Math.max(this.left == null ? 0 : this.left.getHeight(), this.right == null ? 0 : this.right.getHeight()) + 1;
    }
    // 返回该结点的左子树的高度
    public int leftHeight() {
        if (this.left != null) {
            return this.left.getHeight();
        }
        return 0;
    }
    // 返回该结点的右子树的高度
    public int rightHeight() {
        if (this.right != null) {
            return this.right.getHeight();
        }
        return 0;
    }

    // 左旋转
    public void leftRotate() {
        // 创建一个新结点，值等于当前节点的值
        Node newNode = new Node(this.val);
        // 新结点的左子树指向当前节点的左子树
        newNode.left = this.left;
        // 新结点的右子树指向当前节点的右子树的左子树
        newNode.right = this.right.left;
        // 当前节点的值赋值为右子树的值
        this.val = this.right.val;
        // 当前节点的右子树指向当前节点的右子树的右子树
        this.right = this.right.right;
        // 当前节点的左子树指向新结点
        this.left = newNode;
    }

    // 右旋转
    public void rightRotate() {
        Node newNode = new Node(this.val);
        newNode.right = this.right;
        newNode.left = this.left.right;
        this.val = this.left.val;
        this.left = this.left.left;
        this.right = newNode;
    }


    @Override
    public String toString() {
        return "Node{" +
                "val=" + val +
                '}';
    }

    // 中序遍历
    public void infixOrder() {
        if (this.left != null) {
            this.left.infixOrder();
        }
        System.out.println(this);
        if (this.right != null) {
            this.right.infixOrder();
        }
    }

    /**
     * 使用递归添加节节点，满足二叉排序树的要求
     * @param node
     */
    public void add(Node node) {
        if (node == null) return;

        // 判断当前传入的节点的值，和当前子树的根节点的值的关系
        if (this.val > node.val) {
            // 如果当前节点的左子节点为null
            if (this.left == null) {
                this.left = node;
            }else {
                this.left.add(node);
            }
        }else {
            // 表示添加的节点的值大于当前节点的值
            if (this.right == null) {
                this.right = node;
            }else {
                this.right.add(node);
            }
        }

        // 每添加完一个结点，需要判断当前节点的左子树高度与右子树高度差是否大于1,在来进行旋转
        int len = this.rightHeight() - this.leftHeight();
        if (len > 1) {
            // 考虑双旋转问题
            if (this.right != null && this.right.leftHeight() > this.right.rightHeight()) {
                //先将右子节点 进行右旋
                this.right.rightRotate();
                // 在将当前节点进行左旋
                this.leftRotate();
            }else {
                this.leftRotate();
            }
        }else if (len < -1) {
            // 以上同理
            if (this.left != null && this.left.rightHeight() > this.left.leftHeight()) {
                this.left.leftRotate();
                this.rightRotate();
            }else {
                this.rightRotate();
            }
        }else {
            // 不需要旋转,二叉树已经是平衡的
            return;
        }
    }
}

```
