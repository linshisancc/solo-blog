title: Java 数据结构 - Joseph
date: '2019-08-30 23:20:08'
updated: '2019-09-01 17:10:15'
tags: [Java数据结构]
permalink: /articles/2019/08/30/1567178408023.html
---
![](https://img.hacpai.com/bing/20190811.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



# Josephu（约瑟夫、约瑟夫环）问题：
### 什么是约瑟夫问题？
设编号为1，2，… n的n个人围坐一圈，约定编号为`k（1<=k<=n`的人从1开始报数，数到m 的那个人出列，它的下一位又从1开始报数，数到m的那个人又出列，依次类推，直到所有人出列为止，由此产生一个出队编号的序列。
### 解决思路
用一个不带头结点的循环链表来处理Josephu 问题：先构成一个有n个结点的单循环链表，然后由k结点起从1开始计数，计到m时，对应结点从链表中删除，然后再从被删除结点的下一个结点又从1开始计数，直到最后一个结点从链表中删除算法结束。

### 单向环形链表示意图

![17213502019072423082667270259282.png](https://img.hacpai.com/file/2019/08/17213502019072423082667270259282-a97ffbc5.png)

### 约瑟夫问题示意图

![172135020190724231152752988721791.png](https://img.hacpai.com/file/2019/08/172135020190724231152752988721791-30ba93d3.png)

### 代码实现

```
package com.linshisan.datastructure;

/**
 * 约瑟夫问题
 * @Description TODO
 * @Date 2019/8/30 0030 22:12
 * @Author Aaron
 */
public class Joseph {
    public static void main(String[] args) {
        CycleSingleLinkedList cycleSingleLinkedList = new CycleSingleLinkedList();
        cycleSingleLinkedList.addChild(25);
        //cycleSingleLinkedList.showBoys();
        cycleSingleLinkedList.deCycle(5, 25, 25);
    }
}

/**
 * 单向环形链表
 */
class CycleSingleLinkedList {

    Boy front = null; //  指向链表头
    Boy rear = null; //  指向链表尾

    public CycleSingleLinkedList() {}

    /**
     * 生成对应数量的单向环形链表
     * @param num
     */
    public void addChild(int num) {
        if (num < 1) throw new RuntimeException("参数不合法");
        Boy curBoy = null; // 辅助指针帮助构建环形链表
        for (int i = 1; i <= num; i++) {
            Boy boy = new Boy(i);
            if (i == 1) { // 如果是第一个小孩，让 front 指针指向 boy 再让 boy的next指向自己
                front = boy;
                front.setNext(front);// 构成环
                curBoy = front; // 让curBoy指向第一个小孩
            }else {
                curBoy.setNext(boy);
                boy.setNext(front);
                curBoy = boy;
            }
        }
    }

    /**
     * 根据用户的输入，计算出小孩出圈的的顺序
     * @param startNum 表示从第 j 位开始数
     * @param countNum 表示数 k 次
     * @param nums 表示 m 个小孩
     */
    public void deCycle(int startNum, int countNum, int nums) {
        if (front == null || startNum < 1 ||  countNum > nums ) throw new RuntimeException("params is illegal");
        rear = front; // 通过 rear 指针指向链表的最后一个节点
        while (true) {
            if (rear.getNext() == front) break;// 说明 rear 已经 指向最后一个节点
            rear = rear.getNext();
        }
        // 小孩报数前 让front 指针 rear 指针移动 startNum - 1 次
        for (int i = 0; i < startNum - 1; i++) {
            front = front.getNext();
            rear = rear.getNext();
        }

        // 开始让小孩出圈
        while (true) {
            if (rear == front) break; // 只剩最后一个小孩
            // 当小孩报数时 让指针移动 countNum - 1 次
            for (int i = 0; i < countNum - 1; i++) {
                front = front.getNext();
                rear = rear.getNext();
            }
            System.out.printf("小孩:%d出圈\n", front.getNo());
            front = front.getNext();
            rear.setNext(front);
        }
        System.out.printf("最后一个小孩%d出圈", front.getNo());

    }


    /**
     * 遍历环形链表
     */
    public void showBoys() {
        if (front == null) return; // 没有添加小孩
        Boy curBoy = front;
        while (curBoy != null) {
            System.out.printf("小孩:%d\n", curBoy.getNo());
            if (curBoy.getNext() == front) break;// 说明遍历完毕
            curBoy = curBoy.getNext();
        }
    }
}

// 创建孩子节点
class Boy {
    private int no; // 编号
    private Boy next;
    public Boy(int no) {
        this.no = no;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public Boy getNext() {
        return next;
    }

    public void setNext(Boy next) {
        this.next = next;
    }
}
```

### 小结

约瑟夫问题是一个很经典的算法题，其解法有很多种，作者网上找了很多篇文章都细细的体会了别人解题思路，领悟数据结构与算法的无穷魅力 😰 
