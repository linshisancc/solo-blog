title: Java 算法 - RadixSort
date: '2019-09-04 12:52:42'
updated: '2019-09-04 13:05:50'
tags: [Java算法]
permalink: /articles/2019/09/04/1567572762384.html
---
![](https://img.hacpai.com/bing/20190705.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 基数排序
* 将所有待比较数值统一为同样的数位长度，数位较短的数前面补零。然后，从最低位开始，依次进行一次排序。这样从最低位排序一直到最高位排序完成以后, 数列就变成一个有序序列。

* 基数排序是对传统桶排序的扩展，速度很快.
* 基数排序是经典的空间换时间的方式，占用内存很大, 当对海量数据排序时，容易造成 OutOfMemoryError 。
* 基数排序时稳定的。[注:假定在待排序的记录序列中，存在多个具有相同的关键字的记录，若经过排序，这些记录的相对次序保持不变，即在原序列中，r[i]=r[j]，且r[i]在r[j]之前，而在排序后的序列中，r[i]仍在r[j]之前，则称这种排序算法是稳定的；否则称为不稳定的]
* 有负数的数组，我们不用基数排序来进行排序。

#### 图解

![image.png](https://img.hacpai.com/file/2019/09/image-4d20e63f.png)


![image.png](https://img.hacpai.com/file/2019/09/image-c662bc58.png)


![image.png](https://img.hacpai.com/file/2019/09/image-e4d7d938.png)


**从上面不我们不难看出变化的规律, 它排序的次数即为当前数组中的最大数的位数**

> 下面我在代码里作详细的解释

```
/**
 * 基数排序
 * @Description TODO
 * @Date 2019/9/3 0003 21:17
 * @Author Aaron
 */
public class RadixSort {
    public static void main(String[] args) {
        //int arr[] = {53, 3, 542, 748, 241};
        int arr[] = new int[8000000];
        SelectSort.getArr(arr);
        long start = System.currentTimeMillis();
        radixSort(arr);
        long end = System.currentTimeMillis();
        System.out.printf("8000000个随机数使用基数排序所花费毫秒数为: %d 毫秒", end - start);
    }

    public static void radixSort(int arr[]) {

        // 准备二维数组 行表示有10个桶
        int bucket[][] = new int[10][arr.length];
        // 创建一个数组容量为10 用来存放桶里的有效元素个数
        // 比如{1,0,1,2,3...} 其中 1 表示第一个桶里有一个有效元素 依次类推
        int bucketElementCount[] = new int[10];
        int index = 0;
        int max = arr[0];
        // 综合推论过程可以得出以下代码
        // 首先找出数组中的最大值，并获取它是几位数
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        max = (max + "").length();// 获取它是几位数
        for (int i = 0, m = 1; i < max; i++, m *= 10) {
            for (int j = 0; j < arr.length; j++) {
                // 将每个元素的位数取出,这里我们直接操作二进制让其右移
                int digit = arr[j] / m % 10;

                // 如果为负数
                if (digit < 0) {
                    digit = Math.abs(digit);
                }
                // 放入对应的桶中
                // 这里二维数组的列数表示多少个桶，其列数表示该桶的容量(即可存放数据的个数)
                // 我们将其理解为10个横着的桶，编号依次从上至下排列
                /**               桶编号
                 *  241 0 0 0 0   0
                 *   0  0 0 0 0   1
                 *  742 0 0 0 0   2
                 *  53  3 0 0 0   3 -->
                 *  14  0 0 0 0   4
                 *  0   0 0 0 0   5
                 *  0   0 0 0 0   6
                 *  0   0 0 0 0   7
                 *  748 0 0 0 0   8
                 *  0   0 0 0 0   9
                 */
                // 比如 53 就要存储到对应的 bucket[3][bucketElementCount[digit]] 中 即 bucket[3][0]
                // 其中 bucketElementCount[3] 表示放入该桶中的有效个数，每次放入一个就要 + 1
                bucket[digit][bucketElementCount[digit]++] = arr[j];
            }
            // 此时将桶中的数据放入原数组
            index = 0;
            for (int k = 0; k < bucketElementCount.length; k++) {
                // 如果桶中有数据则进行放置
                if (bucketElementCount[k] != 0) {
                    // 遍历第 k 个桶 从 n 到 bucketElementCount[k] 次，并将其在二维数组中存放的数据依次放入原数组中
                    for (int n = 0; n < bucketElementCount[k]; n++) {
                        arr[index++] = bucket[k][n];
                    }
                }
                // 清空桶中存放的个数
                bucketElementCount[k] = 0;
            }
            //System.out.printf("第%d轮排序后的结果", i + 1);
            //System.out.println(Arrays.toString(arr));
        }

        // 以下是对排序的步骤进行拆分
        /*
        // 第一轮排序
        for (int i = 0; i < arr.length; i++) {
            // 将每个元素的个位数取出，看放置在那个桶中
            int j = arr[i] / 1% 10;
            //
            bucket[bucketElementCount[j]++][j] = arr[i];
        }
        // 此时将桶中的数据放入原数组
        int index = 0;
        for (int k = 0; k < bucketElementCount.length; k++) {
            // 如果桶中有数据则进行放置
            if (bucketElementCount[k] != 0) {
                // 遍历第 k 个桶的 bucketElementCount[k] 次，将其在二维数组中存放的数据放入原数组中
                for (int n = 0; n < bucketElementCount[k]; n++) {
                    arr[index++] = bucket[n][k];
                }
            }
            // 清空桶中存放的个数
            bucketElementCount[k] = 0;
        }
        System.out.println("第一轮排序:" + Arrays.toString(arr));

        // 第二轮排序
        for (int i = 0; i < arr.length; i++) {
            // 将每个元素的个位数取出，看放置在那个桶中
            int j = arr[i] / 10 % 10;
            //
            bucket[bucketElementCount[j]++][j] = arr[i];
        }
        // 此时将桶中的数据放入原数组
        index = 0;
        for (int k = 0; k < bucketElementCount.length; k++) {
            // 如果桶中有数据则进行放置
            if (bucketElementCount[k] != 0) {
                // 遍历第 k 个桶的 bucketElementCount[k] 次，将其在二维数组中存放的数据放入原数组中
                for (int n = 0; n < bucketElementCount[k]; n++) {
                    arr[index++] = bucket[n][k];
                }
            }
            // 清空桶中存放的个数
            bucketElementCount[k] = 0;
        }
        System.out.println("第二轮排序:" + Arrays.toString(arr));

        // 第三轮排序
        for (int i = 0; i < arr.length; i++) {
            // 将每个元素的个位数取出，看放置在那个桶中
            int j = arr[i] / 100 % 10;
            //
            bucket[bucketElementCount[j]++][j] = arr[i];
        }
        // 此时将桶中的数据放入原数组
        index = 0;
        for (int k = 0; k < bucketElementCount.length; k++) {
            // 如果桶中有数据则进行放置
            if (bucketElementCount[k] != 0) {
                // 遍历第 k 个桶的 bucketElementCount[k] 次，将其在二维数组中存放的数据放入原数组中
                for (int n = 0; n < bucketElementCount[k]; n++) {
                    arr[index++] = bucket[n][k];
                }
            }

        }
        System.out.println("第三轮排序:" + Arrays.toString(arr));
       */
    }
}

```
于此同时我也对其做了个速度测试，1 s 都不用，挺夸张的，因为我这没有写负数的处理，所以感兴趣的小伙伴可以自行百度查阅。
![image.png](https://img.hacpai.com/file/2019/09/image-b1f0c444.png)




