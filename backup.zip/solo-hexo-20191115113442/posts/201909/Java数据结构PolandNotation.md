title: Java 数据结构 - PolandNotation
date: '2019-09-01 16:47:19'
updated: '2019-09-01 17:07:07'
tags: [Java数据结构]
permalink: /articles/2019/09/01/1567327639462.html
---
![](https://img.hacpai.com/bing/20171229.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


# 前缀、中缀、后缀表达式
### 前缀表达式(波兰表达式)
1)  前缀表达式又称波兰表达式, **前缀表达式的运算符位于操作数之前**
2)  **比如:**   `(3+4)*5-6` 对应的前缀表达式为  `- * + 3 4 5 6`

#### 前缀表达式的计算机求值
从右至左扫描表达式，遇到数字时，将数字压入堆栈，遇到运算符时，弹出栈顶的两个数，用运算符对它们做相应的计算（栈顶元素 和 次顶元素），并将结果入栈；重复上述过程直到表达式最左端，最后运算得出的值即为表达式的结果

例如: (3+4)×5-6 对应的前缀表达式就是 - × + 3 4 5 6 , 针对前缀表达式求值步骤如下:
* 从右至左扫描，将6、5、4、3压入堆栈
* 遇到+运算符，因此弹出3和4（3为栈顶元素，4为次顶元素），计算出3+4的值，得7，再将7入栈
* 接下来是×运算符，因此弹出7和5，计算出7×5=35，将35入栈
* 最后是-运算符，计算出35-6的值，即29，由此得出最终结果

### 中缀表达式
中缀表达式就是常见的运算表达式，如(3+4)×5-6

中缀表达式的求值是我们人最熟悉的，但是对计算机来说却不好操作(前面我们讲的案例就能看的这个问题)，因此，在计算结果时，往往会将中缀表达式转成其它表达式来操作(一般转成后缀表达式.)

### 后缀表达式
后缀表达式又称逆波兰表达式,与前缀表达式相似，只是运算符位于操作数之后

举例说明： (3+4)×5-6 对应的后缀表达式就是 3 4 + 5 × 6 –

![image.png](https://img.hacpai.com/file/2019/09/image-9dfa6656.png)
#### 后缀表达式的计算机求值

从左至右扫描表达式，遇到数字时，将数字压入堆栈，遇到运算符时，弹出栈顶的两个数，用运算符对它们做相应的计算（次顶元素 和 栈顶元素），并将结果入栈；重复上述过程直到表达式最右端，最后运算得出的值即为表达式的结果

例如: (3+4)×5-6 对应的后缀表达式就是 3 4 + 5 × 6 - , 针对后缀表达式求值步骤如下:
* 从左至右扫描，将3和4压入堆栈；
* 遇到+运算符，因此弹出4和3（4为栈顶元素，3为次顶元素），计算出3+4的值，得7，再将7入栈；
* 将5入栈；
* 接下来是×运算符，因此弹出5和7，计算出7×5=35，将35入栈；
* 将6入栈；
* 最后是-运算符，计算出35-6的值，即29，由此得出最终结果

### 目标要求，实现一个逆波兰计算器，功能如下 :
1. 输入一个逆波兰表达式(后缀表达式)，使用自己用单链表实现的栈, 计算其结果
2. 支持小括号和多位数整数

#### 思路分析

**如何将中缀表达式转换为后缀表达式**
1. 初始化两个栈：运算符栈s1和储存中间结果的栈s2；
2. 从左至右扫描中缀表达式；
3. 遇到操作数时，将其压s2；
4. 遇到运算符时，比较其与s1栈顶运算符的优先级：
   1)  如果s1为空，或栈顶运算符为左括号“(”，则直接将此运算符入栈；
   2)  否则，若优先级比栈顶运算符的高，也将运算符压入s1；
   3)  否则，将s1栈顶的运算符弹出并压入到s2中，再次转到(4-1)与s1中新的栈顶运算符相比较；
5. 遇到括号时：
   1) 如果是左括号“(”，则直接压入s1
   2) 如果是右括号“)”，则依次弹出s1栈顶的运算符，并压入s2，直到遇到左括号为止，此时将这一对括号丢弃
6. 重复步骤2至5，直到表达式的最右边
7. 将s1中剩余的运算符依次弹出并压入s2
8. 依次弹出s2中的元素并输出，结果的逆序即为中缀表达式对应的后缀表达式

#### 代码实现

```
/**
 * 波兰计算器
 * @Description TODO
 * @Date 2019/9/1 0001 13:33
 * @Author Aaron
 */
public class PolandNotation {
    public static void main(String[] args) {
        //String exp = "2 3 + 4 * 2 -";
        //List<String> suffixList = toSuffixList(exp);
        //int res = calculate(suffixList);
        //System.out.printf("后缀表达式: %s 的计算结果为 %d \n", exp, res);
        List<String> infixList = toInfixList("((22+23)*2-2)");
        String infix = "2+((2+3)*2)-2+(104/2-30+4)+24";  //2+((2+3)*2)-2+(104/2-30+4)+24
        List<String> list = infixToSuffix(infix);
        System.out.println(list);
        System.out.printf("中缀表达式 %s 转后缀表达式计算的结果为 %d \n",infix, calculate(list));

    }


    /**
     * 中缀表达式转后缀表达式 返回一个list
     * @param infix
     * @return
     */
    public static List<String> infixToSuffix(String infix) {
        if (infix.length() <= 0 || infix == null)
            throw new RuntimeException("The infix is illegal");
        //
        LinkedListStack<String> s1 = new LinkedListStack<>(infix.length());
        List<String> s2 = new ArrayList<>();// 因为整个过程s2没用发生pop操作 所以我们用list来代替
        // 开始遍历
        List<String> list = toInfixList(infix);// 转换为list集合便于操作
        int index = 0;
        for (String item : list) {

            if (item.matches("\\d+")) {
                // 遇到数直接 push 到s2
                s2.add(item);
            }else if (item.equals("(")) {
                s1.push(item);
            }else if (item.equals(")")) {
                // 如果是右括号则依次弹出s1栈顶运算符，并加入s2，直到遇到左括号为止,此时将这一对括号丢弃
                while (!s1.peek().equals("(")) {
                    s2.add(s1.pop());
                }
                s1.pop();// 弹出 "(" 即消除一对括号
            }
            else {
                // 如果s1中
                // 当 item 的优先级小于等于s1栈顶运算符时,将s1栈顶运算符弹出并加入s2中, 然后再与s1中新的栈顶运算符进行比较
                // 在这里我们不将
                while (!s1.isEmpty() && !s1.peek().equals("(") && priority(item.charAt(0)) <= priority(s1.peek().charAt(0))) {
                    s2.add(s1.pop());
                }
                // 还需要将 item 压入栈
                s1.push(item);
            }

        }

        // 将 s1 中剩余的运算符依次加进s2中
        while (!s1.isEmpty()) {
            s2.add(s1.pop());
        }

        return s2; // 因为我们是用的list代替栈，所以按顺序输出就是相应的后缀表达式list

    }

    /**
     * 将中缀表达式转为list集合
     * @param infix
     * @return
     */
    public static List<String> toInfixList(String infix) {
        if (infix.length() <= 0 || infix == null)
            throw new RuntimeException("The infix is illegal");
        char ch = ' ';
        int index = 0;
        List<String> list = new ArrayList<>();
        String str = "";
        for (; ;) {
            ch = infix.substring(index, index + 1).charAt(0);
            // 如果是非数字 则加入
            if (ch < 48 || ch > 57) {
                list.add(ch + "");
            }else {
                str += ch;
                // 需要考虑多位数  '0' -> 48 '9' -> 57
                // 如果当前数字为最后一位时，直接加入list
                if (index == infix.length() - 1) {
                    list.add(str);
                }else {
                    char next = infix.substring(index + 1, index + 2).charAt(0);
                    if (next < 48 || next > 57) { // 如果当前字符的下一位为数字则继续循环否则就加入list 然后清空str
                        list.add(str);
                        str = "";
                    }
                }
            }
            index++;
            if (index == infix.length()) {
                break;
            }

        }
        return list;
    }

    /**
     * 返回优先级对应的值
     * @param ope
     * @return
     */
    public static int priority(char ope) {
        if (ope == '+' || ope == '-') {
            return 0;
        }else if (ope == '*' || ope == '/') {
            return 1;
        }else {
            throw new RuntimeException("The priority is illegal");
        }
    }

    /**
     * 通过对后缀表达式进行计算
     * @param list
     * @return
     */
    public static int calculate(List<String> list) {
        // 创建一个栈
        LinkedListStack<String> stack = new LinkedListStack<>(list.size());

        for (String s : list) {
            // 使用正则表达式来判断数
            if (s.matches("\\d+")) { //匹配多位数
                stack.push(s);
            }else {
                // 如果是运算符
                int num1 = Integer.parseInt(stack.pop());
                int num2 = Integer.parseInt(stack.pop());
                int res = 0;
                if (s.equals("+")) {
                    res = num1 + num2;
                } else if (s.equals("-")) {
                    res = num2 - num1;
                } else if (s.equals("*")) {
                    res = num1 * num2;
                } else if (s.equals("/")){
                    res = num2 / num1;
                }else {
                    throw new RuntimeException("The Expression is illegal");
                }
                stack.push(res + "");
            }
        }
        // 将栈顶元素返回即可
        return Integer.parseInt(stack.pop());
    }



    /**
     * 将一个后缀表达式中的数和运算符依次放入list中方便遍历
     * @param suffixExpression
     * @return
     */
    public static List<String> toSuffixList(String suffixExpression){
        if (suffixExpression.length() <= 0 || suffixExpression == null)
            throw new RuntimeException("the param is illegal");
        List<String> list = new ArrayList<>();
        String[] s = suffixExpression.split(" ");
        for (String item : s) {
            list.add(item);
        }
        return list;
    }

}
```

此时我们将我们所熟悉的中缀表达式扔进去 2+((2+3)*2)-2+(104/2-30+4)+24

![QQ图片20190901165557.png](https://img.hacpai.com/file/2019/09/QQ图片20190901165557-058902a8.png)

此时拿出计算器来指点一番 果不其然 答案正确了。。

总结下，学习完栈这个数据结构然后理解了计算器原理，后面如果有时间可以再把这个逆波兰计算器的完整版给写一写 😰 
