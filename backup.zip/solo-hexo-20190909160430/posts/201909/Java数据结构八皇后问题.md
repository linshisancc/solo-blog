title: Java 数据结构-八皇后问题
date: '2019-09-02 15:44:29'
updated: '2019-09-02 15:44:29'
tags: [Java数据结构]
permalink: /articles/2019/09/02/1567410269318.html
---
![](https://img.hacpai.com/bing/20190420.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 八皇后问题(回溯算法)

#### 什么是八皇后问题

简单来说就是将八位皇后放在一张8x8的棋盘上，使得每位皇后都无法吃掉别的皇后，（即任意两个皇后都不在同一条横线，竖线和斜线上），问一共有多少种摆法。

![image.png](https://img.hacpai.com/file/2019/09/image-778e33ab.png)

网上有很多种解答方法， 如果对这个问题不太了解的可以先行百度查阅一番再来看看我的代码

#### 八皇后问题算法思路分析

* 第一个皇后先放第一行第一列
* 第二个皇后放在第二行第一列、然后判断是否OK， 如果不OK，继续放在第二列、第三列、依次把所有列都* * 放完，找到一个合适
* 继续第三个皇后，还是第一列、第二列……直到第8个皇后也能放在一个不冲突的位置，算是找到了一个正确解
* 当得到一个正确解时，在栈回退到上一个栈时，就会开始回溯，即将第一个皇后，放到第一列的所有正确解，全部得到.
* 然后回头继续第一个皇后放第二列，后面继续循环执行 1,2,3,4的步骤

**这里我们用一维数组来解决问题**

```
arr = {0, 4, 7, 5, 2, 6, 1, 3}

```

```
这里 数组的下标 index 表示第 index + 1 行 也表示第 index + 1 个皇后

下标所对应的值  arr[index] = val 表示该皇后所在第 val + 1 列  比如 4 就表示第 2 个皇后放在第 2 行第 5 列
```

代码实现
```
/**
 * 八皇后问题
 * @Description TODO
 * @Date 2019/9/2 0002 13:37
 * @Author Aaron
 */
public class Queen8 {

    // 表示共有多少个皇后
    int maxQueen = 8;
    // 定义数组，保存皇后放置的位置的结果 如 arr = {0, 4, 7, 5, 2, 6, 1, 3}
    // 这里 数组的下标 index 表示第 index + 1 行 也表示第 index + 1 个皇后
    // 下标所对应的值  arr[index] = val 表示该皇后所在第 val + 1 列  比如 4 就表示第 2 个皇后放在第 2 行第 5 列
    int arr[] = new int[maxQueen];
    static int count = 0;
    public static void main(String[] args) {
        Queen8 queen8 = new Queen8();
        queen8.putQueen(0);
        System.out.printf("共有%d种放置方法", count);
    }

    /**
     * 放置第 n 个皇后
     * @param n
     */
    public void putQueen(int n) {
        if (n == maxQueen) { // 当 n 等于 8 是说明 8 个皇后已经放置完毕
            print();
            return;
        }

        // 依次放入皇后并检测是否冲突
        for (int i = 0; i < maxQueen; i++) {
            // 先把当前这个皇后放入到该行的第一列
            arr[n] = i;
            if (!isConflict(n)) {
                // 如果不冲突 就放第 n + 1个皇后
                putQueen(n + 1);
            }
        }
    }

    /**
     * 判断第 n 个皇后是否和第 n - 1 个皇后冲突
     * @param n 表示第 n 个皇后
     * @return
     */
    public boolean isConflict(int n) {
        for (int i = 0; i < n; i++) {
            if (arr[i] == arr[n] || Math.abs(n - i) == Math.abs(arr[n] - arr[i]))  {
                // arr[i] == arr[n] 表示是否在同一列
                // Math.abs(n - i) 表示两个皇后所在行的差 Math.abs(arr[n] - arr[i]) 表示两个皇后所在列的差 如果相等则表示两个皇后在斜线上
                return true;
            }
        }
        return false;
    }


    // 输出皇后放置的位置
    public void print() {
        count++;
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

}
```
