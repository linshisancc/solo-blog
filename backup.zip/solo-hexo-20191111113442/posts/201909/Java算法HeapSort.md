title: Java 算法 - HeapSort
date: '2019-09-06 10:36:59'
updated: '2019-09-06 10:36:59'
tags: [Java算法]
permalink: /articles/2019/09/06/1567737419817.html
---
![](https://img.hacpai.com/bing/20180319.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 堆排序
1. 堆排序是利用堆这种数据结构而设计的一种排序算法，堆排序是一种选择排序，它的最坏，最好，平均时间复杂度均为O(nlogn)，它也是不稳定排序。
2. 堆是具有以下性质的完全二叉树：每个结点的值都大于或等于其左右孩子结点的值，称为大顶堆, 注意 : 没有要求结点的左孩子的值和右孩子的值的大小关系。
3. 每个结点的值都小于或等于其左右孩子结点的值，称为小顶堆

**如下**

![image.png](https://img.hacpai.com/file/2019/09/image-2c1a33ec.png)

![image.png](https://img.hacpai.com/file/2019/09/image-77846942.png)


#### 我们对堆中的节点按层次编号放入数组中则变成了

![image.png](https://img.hacpai.com/file/2019/09/image-3d76dec7.png)

> **很显然这是一个大顶堆**

**大顶堆的特点:arr[i] >= arr[i * 2 + 1] && arr[i] >= arr[i * 2 + 2]**

**小顶堆的特点:arr[i] <= arr[i * 2 + 1] && arr[i] <= arr[i * 2 + 2]**

#### 注意 这里的 i 表示的是非叶子节点所在数组的下标，可以结合顺序存储二叉树的特点来看

#### 代码实现并测其对800w个数据的排序速度

```
/**
 * 堆排序
 * @Description TODO
 * @Date 2019/9/5 20:37
 * @Author Aaron
 */
public class HeapSort {
    public static void main(String[] args) {

        //int arr[] = {4, 6, 8, 5, 9};
        int arr[] = new int[8000000];
        SelectSort.getArr(arr);
        long start = System.currentTimeMillis();
        heapSort(arr);
        long end = System.currentTimeMillis();
        System.out.printf("堆排序所花费的时间为%d毫秒" ,end - start);
    }

    /**
     * 堆排序
     * @param arr
     */
    public static void heapSort(int arr[]) {
        int temp = 0;
        createMaxHeap(arr);
        /**
         * 将堆顶元素与末尾元素进行交换，将最大元素放到数组末端
         * 重新调整结构，使其满足堆定义，然后继续交换堆顶元素与末尾元素，反复执行，直到整个序列有序
         */
        for (int j = arr.length - 1; j > 0 ; j--) {
            temp = arr[j];
            arr[j] = arr[0];
            arr[0] = temp;
            adjustHeap(arr, 0, j);
        }
    }

    /**
     * 创建生成一个大顶堆
     * @param arr
     */
    public static void createMaxHeap(int arr[]) {
        // 将无序数组构建成一个堆，根据升序或降序选择大堆顶或小堆顶
        for (int i = arr.length / 2 - 1; i >= 0 ; i--) {
            adjustHeap(arr, i, arr.length);
        }
    }

    /**
     * 调整以i对应的非子节点数为最大顶堆
     * @param arr 待排序的数组
     * @param i 表示非叶子节点所在数组下标
     * @param length 表示对多少个元素进行调整， length 实在逐渐减少
     */
    public static void adjustHeap(int arr[], int i, int length) {
        int temp = arr[i];// 将原来的数保存到temp中
        // 开始调整
        // k = i * 2 + 1 表示i节点的的左子节点
        for (int k = i * 2 + 1; k < length; k = k * 2 + 1) {
            if (k + 1 < length && arr[k] < arr[k + 1]) {
                // 表示右子节点值大于左子节点值
                // 如果大于则将k置为i的右子节点
                k++;
            }
            if (arr[k] > temp) {
                // 把较大值赋给当前节点
                arr[i] = arr[k];
                // 让当前非叶子节点arr[i] 变为arr[k] 即i = k 继续循环判断
                i = k;
            }else {
                break;
            }
        }
        // 循环结束后，我们已经将以i为父节点的树的最大值放在了顶部
        arr[i] = temp;// 将temp值放在调整后的位置
    }
}
```
> 我们可以看见速度还是挺快的 

![image.png](https://img.hacpai.com/file/2019/09/image-832e65f4.png) 
