title: Java 数据结构 - 顺序存储二叉树
date: '2019-09-06 10:18:43'
updated: '2019-09-06 10:19:08'
tags: [Java数据结构]
permalink: /articles/2019/09/06/1567736323185.html
---
![](https://img.hacpai.com/bing/20180319.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 顺序存储二叉树
**特点**
* 顺序二叉树通常只考虑完全二叉树
* 第n个元素的左子节点为  2 * n + 1 
* 第n个元素的右子节点为  2 * n + 2
* 第n个元素的父节点为  (n-1) / 2

![image.png](https://img.hacpai.com/file/2019/09/image-2600cfe2.png)

**其中n表示二叉树中第几个元素(从0开始)**

#### 代码实现

```
/**
 * 顺序存储二叉树
 * @Description
 * @Date 2019/9/6 9:04
 * @Author Aaron
 */
public class ArrayBinaryTreeDemo {
    public static void main(String[] args) {
        int arr[] = {4, 5, 2, 6, 7, 3, 1};
        ArrayBinaryTree arrayBinaryTree = new ArrayBinaryTree(arr);
        System.out.println(Arrays.toString(arr));

    }

}

class ArrayBinaryTree {
    private int arr[] = {};
    public ArrayBinaryTree(int arr[]) {
        this.arr = arr;
    }
    private void preOrder() {
        this.preOrder(0);
    }

    private void midOrder() {
        this.midOrder(0);
    }

    private void postOrder() {
        this.postOrder(0);
    }

    // 前序遍历
    public void preOrder(int index) {
        if (null == arr || arr.length <= 0) return;
        System.out.println(arr[index]);

        // 往左递归遍历
        if ((index * 2 + 1) < arr.length) {
            preOrder(index * 2 + 1);
        }
        // 往右递归遍历
        if ((index * 2 + 2) < arr.length) {
            preOrder(index * 2 + 2);
        }
    }

    // 中序遍历
    public void midOrder(int index) {
        if (null == arr || arr.length <= 0) return;

        // 往左递归遍历
        if ((index * 2 + 1) < arr.length) {
            midOrder(index * 2 + 1);
        }

        System.out.println(arr[index]);

        // 往右递归遍历
        if ((index * 2 + 2) < arr.length) {
            midOrder(index * 2 + 2);
        }
    }

    // 后序遍历
    public void postOrder(int index) {
        if (null == arr || arr.length <= 0) return;

        // 往左递归遍历
        if ((index * 2 + 1) < arr.length) {
            postOrder(index * 2 + 1);
        }

        // 往右递归遍历
        if ((index * 2 + 2) < arr.length) {
            postOrder(index * 2 + 2);
        }
        System.out.println(arr[index]);

    }
}

```
