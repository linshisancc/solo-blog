title: Java 算法 - InsertValueSearch
date: '2019-09-04 13:02:11'
updated: '2019-09-04 13:05:42'
tags: [Java算法]
permalink: /articles/2019/09/04/1567573331856.html
---
![](https://img.hacpai.com/bing/20190208.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 插值查找

* 插值查找算法类似于二分查找，不同的是插值查找每次从自适应mid处开始查找。
* 将折半查找中的求mid 索引的公式 , low 表示左边索引left, high表示右边索引right. key 就是前面我们讲的  findVal
* ![image.png](https://img.hacpai.com/file/2019/09/image-35cd0ee4.png)
* 其代码形式为 ``int mid = low + (high - low) * (key - arr[low]) / (arr[high] - arr[low])``  

**代码实现**

```
/**
 * 插值查找
 * @Description TODO
 * @Date 2019/9/4 10:34
 * @Author Aaron
 */
public class InsertValueSearch {
    public static void main(String[] args) {
//        int arr[] = new int[100];
//        for (int i = 0; i < arr.length; i++) {
//            arr[i] = i + 1;
//        }
          int arr[] = {1, 8, 10, 89, 1000, 1234};

          int index = insertValue(arr, 0, arr.length - 1, 8);
          System.out.println("找到的下标为 " + index);
    }

    /**
     * 插值查找算法 在二分法上进行了优化，增强了对 mid值的自适应, 也只适用有序的列表
     * @param arr 目标数组
     * @param left 左下标
     * @param right 右下标
     * @param findVal 待查找的值
     * @return 如果找到则返回对应的下标 反之返回-1
     */
    public static int insertValue(int arr[], int left, int right, int findVal) {
        System.out.println("插值查找次数~~");
        if (left > right || findVal < arr[0] || findVal > arr[arr.length - 1]) return -1;
        int mid = left + (right - left) * (findVal - arr[left]) / (arr[right] - arr[left]);
        if (arr[mid] > findVal) {
            return insertValue(arr, left, mid - 1, findVal);
        }else if (arr[mid] < findVal) {
            return insertValue(arr, mid + 1, right, findVal);
        }else {
            return mid;
        }
    }
}
```
#### 注意 
对于数据量较大，数据分布比较均匀的查找表来说，采用插值查找, 速度较快, 反之折半查找法可能更优些
