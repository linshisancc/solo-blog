title: Java 数据结构 - SparseArray
date: '2019-08-28 21:08:05'
updated: '2019-08-28 21:08:05'
tags: [Java数据结构]
permalink: /articles/2019/08/28/1566997684976.html
---
![](https://img.hacpai.com/bing/20190606.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 稀疏数组

如果一个数组(包括多维数组)中的大部分元素为0，或者为同一个值的数组时，可以使用稀疏数组来保存该数组，节约空间。

一般来说，稀疏数组的处理方法是：  
* 记录数组一共有几行几列，有多少个不同的数值。  
* 把具有不同值的元素的行列及记录在一个小规模的数组中，从而缩小程序的规模。  
如图所示，一般来说，第一行存取几行几列以及几个数值。

#### 图解

![sparseArray.webp](https://img.hacpai.com/file/2019/08/sparseArray-9b276679.webp)


#### 应用

1. 可以使用稀疏数组来保留类似前面的二维数组(棋盘，地图等)  
2. 把稀疏数组存盘，并且可以重新恢复原来的二维数组数。

#### 代码实现

```
/**
 * SparseArray
 * @Author Aaron
 */
public class SparseArray {
    public static void main(String[] args) throws Throwable {
        int chessArr[][] = new int[11][11];
        // 0 没有棋子 1 黑子 2 蓝子
        chessArr[1][2] = 1;
        chessArr[2][3] = 2;
        chessArr[4][5] = 1;
        // 打印二维数组
        //printArr(chessArr);
        int sum = 0; // 记录二维数组中的有效值个数
        for (int i = 0; i < chessArr.length; i++) {
            for (int j = 0; j < chessArr.length; j++) {
                if (chessArr[i][j] != 0) {
                    sum++;
                }
            }
        }

        // 创建稀疏数组
        int[][] sparseArr = new int[sum + 1][3];
        sparseArr[0][0] = 11;
        sparseArr[0][1] = 11;
        sparseArr[0][2] = sum;
        int count = 0;
        for (int i = 0; i < chessArr.length; i++) {
            // 遍历行
            for (int j = 0; j < chessArr.length; j++) {
                // 遍历列
                if (chessArr[i][j] != 0) {
                    count++;
                    sparseArr[count][0] = i;
                    sparseArr[count][1] = j;
                    sparseArr[count][2] = chessArr[i][j];
                }
            }
        }

        // 写出稀松数组存储到文件中
        write(sparseArr, "map.data");

        // 读取文件中的稀松数组
        int[][] sparseArr2 = read("map.data");

        int chessArr2[][] = new int[sparseArr2[0][0]][sparseArr2[0][1]];

        // 从第二行开始取值
        for (int i = 1; i < sparseArr.length; i++) {
            chessArr2[sparseArr[i][0]][sparseArr[i][1]] = sparseArr[i][2];
        }

        //System.out.println("#######################");
        printArr(chessArr2);

    }

    public static int[][] read(String fileName) throws Throwable {
        if (fileName.equals("") || null == fileName) return null;
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName));
        int[][] arr = (int[][]) ois.readObject();
        ois.close();
        return arr;
    }

    public static void write(int[][] arr, String fileName) throws IOException {
        if (fileName.equals("") || null == fileName) return;
        File file = new File(fileName);
        if (!file.exists()) {
            if (file.getParentFile() != null) file.getParentFile().mkdir();
            file.createNewFile();
        }
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
        oos.writeObject(arr);
        oos.close();
    }

    /**
     * 打印二维数组
     * @param arr
     */
    public static void printArr(int[][] arr) {
        for (int[] row : arr) {
            for (int value : row) {
                System.out.printf("%d\t", value);
            }
            System.out.println();
        }
    }
}
```

#### 小结

`SparseAaary` 在一定程度上节省了很多不必要的空间，避免了系统资源的浪费，非常不错。
