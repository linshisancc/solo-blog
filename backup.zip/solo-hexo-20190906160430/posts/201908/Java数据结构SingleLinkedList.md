title: Java 数据结构 - SingleLinkedList
date: '2019-08-30 18:43:21'
updated: '2019-08-30 18:45:13'
tags: [Java数据结构]
permalink: /articles/2019/08/30/1567161801851.html
---
![](https://img.hacpai.com/bing/20180222.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 单链表

学习了单链表，于是乎来手写个单链表实现简单的curd，并且实现了几个简单的问题 比如 如何逆转单链表，如何合并两个有序链表 ❤️ 

**上代码** :

```
package com.linshisan.datastructure;


import java.util.Stack;

/**
 * 要求: 实现单链表的基本操作crud，能够根据编号排序
 * @Description TODO
 * @Date 2019/8/29 0029 20:48
 * @Author Aaron
 */
public class SingleLinkedListDemo {
    public static void main(String[] args) {
        SingleLinkedList singleLinkedList = new SingleLinkedList();
        Node node1 = new Node(1, "张三");
        Node node2 = new Node(3, "李四");
        Node node3 = new Node(5, "王五");
        Node node4 = new Node(7, "小白");
        singleLinkedList.add(node1);
        singleLinkedList.add(node2);
        singleLinkedList.add(node3);
        singleLinkedList.add(node4);
        singleLinkedList.list();
        System.out.println("#########################");
        Node node5 = new Node(1, "aa");
        Node node6 = new Node(4, "bb");
        Node node7 = new Node(6, "cc");
        Node node8 = new Node(8, "dd");
        SingleLinkedList singleLinkedList1 = new SingleLinkedList();
        singleLinkedList1.add(node5);
        singleLinkedList1.add(node6);
        singleLinkedList1.add(node7);
        singleLinkedList1.add(node8);
        singleLinkedList1.list();
        System.out.println("#####################");
        Node node = SingleLinkedList.mergeList(singleLinkedList.getHead().next, singleLinkedList1.getHead().next);
        System.out.println(node);
        //Node node = SingleLinkedList.reverseList2(singleLinkedList.getHead().next);
        //System.out.println(node);
        /*
        singleLinkedList.remove(1);
        System.out.println("############");
        singleLinkedList.list();
        System.out.println("############");
        singleLinkedList.remove(5);
        singleLinkedList.update(new Node(2, "大大大"));
        singleLinkedList.list();
        singleLinkedList.remove(3);*/
       // System.out.println("####################################");
        //Node lastIndexList = SingleLinkedList.getLastIndexList(singleLinkedList.getHead(), 2);
        //System.out.println(lastIndexList);
        //SingleLinkedList.reverseList(singleLinkedList.getHead());
        //singleLinkedList.list();
        //Node node = SingleLinkedList.reverseList2(singleLinkedList.getHead());
        //SingleLinkedList.reversePrint1(singleLinkedList.getHead().next);
        //System.out.println("####################################");
        //SingleLinkedList.reversePrint2(singleLinkedList.getHead());

    }
}

/**
 * 创建单链表
 */
class SingleLinkedList {
    private Node head; // 构建链表的头
    public static final String EMPTY_EXCEPTION = "The SingleLinkedList is empty";
    public SingleLinkedList() {
        // 初始化链表头
        this.head = new Node(0, "");
    }

    public Node getHead() {
        return head;
    }

    /**
     * 逆转单链表
     * @param head
     */
    public static void reverseList(Node head) {
        // 如果只有一个节点则无需输出
        if (head.next == null || head.next.next == null) return;
        Node temp = head.next;
        Node next = null;
        Node reverseHead = new Node(0, "");
        while (temp != null) {
            next = temp.next; // 将当前节点的下一节点保存
            temp.next = reverseHead.next;//
            reverseHead.next = temp;
            temp = next;// temp 后移
        }
        head.next = reverseHead.next;
    }

    /**
     * 使用递归逆转单链表
     * @param head
     * @return
     */
    public static Node reverseList2(Node head) {
            if (head == null || head.next == null) return head;
            Node temp = head.next;
            Node reverseNode = reverseList2(head.next);
            temp.next = head;
            head.next = null;
            return reverseNode;
    }


    /**
     * 使用递归逆序打印单链表
     * @param head
     */
    public static void reversePrint1(Node head) {
        if (head == null) return;
        reversePrint1(head.next);
        System.out.println(head);
    }

    /**
     * 使用 stack 逆序打印单链表
     * @param head
     */
    public static void  reversePrint2(Node head) {
        if (head.next == null) return;
        Node temp = head.next;
        Stack stack  = new Stack();
        while (temp != null) {
            stack.push(temp);
            temp = temp.next;
        }
        while (stack.size() > 0) {
            System.out.println(stack.pop());
        }
    }


    /**
     * 合并两个排序链表要求有序
     * @param node1
     * @param node2
     * @return
     */
    public static Node mergeList(Node node1, Node node2) {
        if (node1 == null) return node2;
        if (node2 == null) return node1;
        Node head = new Node(0, "");
        Node pre = head;
        while (node1 != null && node2 != null) {
            // 谁小就把它拼到 pre 后面
            if (node1.no <= node2.no) {
                pre.next = node1;
                node1 = node1.next;
            }else {
                pre.next = node2;
                node2 = node2.next;
            }
            pre = pre.next;
        }
        // 拼接剩下的节点
        pre.next = node1 == null ? node2 : node1;
        return head.next;
    }

    /**
     * 返回单链表中倒数第 k 个节点
     * @param head
     * @param index
     */
    public static Node getLastIndexList(Node head, int index) {
        int length = getLength(head); // 返回单链表的长度
        if (head.next == null || index <= 0 || index > length ) return null;
        Node temp = head.next;
        for (int i = 0; i < length - index ; i++) {
            // length -> 3  index -> 1  3 - 1 = 2 返回倒数第 1 个节点即循环2 次
            temp = temp.next;
        }
        return temp;
    }



    /**
     * 返回单链表的长度 (有效数据)
     * @param head
     * @return
     */
    public static int getLength(Node head) {
        if (head.next == null) return 0;
        Node temp = head.next;
        int count = 0;
        while (temp != null) {
            count++;
            temp = temp.next;
        }
        return count;
    }


    public void add(Node node) {
        Node temp = head;
        while (true) {
            if (temp.next == null) {
                temp.next = node;
                break;
            }
            temp = temp.next;
        }

    }


    /**
     * 根据编号排序插入链表中且编号不可重复
     * @param node
     */
    public void addByOrder(Node node) {
        Node temp = head;// 因为链表头节点不能动, 所以我们操作一个临时指针用来遍历链表
        boolean flag = false;// 定义一个标示符
        while (true) {
            if (temp.next == null) break;// 找到链表尾
            if (temp.next.no > node.no) {
                // 找到待插入位置，temp 的后面
                break;
            }else if (temp.next.no == node.no) {
                flag = true;
                break;
            }
            temp = temp.next; // temp 往后移动
        }
        if (flag) {
            System.out.printf("编号%d已经存在，插入失败", node.no);
        }else {
            node.next = temp.next;
            temp.next = node;
        }
    }

    // 更新链表中的节信息
    public void update(Node node) {
        if (isEmpty()) throw new RuntimeException(EMPTY_EXCEPTION);
        Node temp = head.next;
        boolean flag = false;
        while (true) {
            if (temp.next == null) break;
            if (temp.no == node.no) {
                flag = true;
                break;
            }
            temp = temp.next;
        }
        if (flag) {
            temp.name = node.name;
        }else {
            System.out.println("不存在该节点，修改失败");
        }
    }

    // 判断链表是非为空
    public boolean isEmpty() {
        return head.next == null;
    }

    // 指定编号删除节点
    public void remove(int no) {
        // 判断链表是否为空
        if (isEmpty()) throw new RuntimeException(EMPTY_EXCEPTION);

        Node temp = head.next;
        boolean flag = false;
        while (true) {
            if (temp.next == null) break;
            if (temp.next.no == no) {
                flag = true;
                break;
            }
            temp = temp.next;
        }
        if (flag) {
            temp.next = temp.next.next;
        }else {
            System.out.println("该编号对应的元素不存在");
        }

    }


    // 遍历链表
    public void list() {
        // 判断链表是否为空
        if (isEmpty()) {
            System.out.println("链表为空");
            return;
        }
        Node temp = head.next;
        while (temp != null) {
            System.out.println(temp);
            temp = temp.next;
        }
    }
}

/**
 * 创建节点
 */
class Node {
    public int no; // 节点编号
    public String name; // 节点名称
    public Node next; // 下一个节点

    public Node(int no, String name) {
        this.no = no;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Node{" +
                "no=" + no +
                ", name=" + name +
                '}';
    }
}

```

然后兴冲冲的跑去 `LeetCode` 上去找虐，突然发现大佬们的解题思路都非常清晰，写出来的代码都很棒，
此时留下了不学无术的泪水~~~
