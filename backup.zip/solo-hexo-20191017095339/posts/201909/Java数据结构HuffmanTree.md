title: Java 数据结构 - HuffmanTree
date: '2019-09-06 14:56:05'
updated: '2019-09-06 15:02:38'
tags: [Java数据结构]
permalink: /articles/2019/09/06/1567752965089.html
---
![](https://img.hacpai.com/bing/20190420.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 赫夫曼树

* 给定n个权值作为n个叶子结点，构造一棵二叉树，若该树的带权路径长度(wpl)达到最小，称这样的二叉树为最优二叉树，也称为哈夫曼树(Huffman Tree), 还有的书翻译为霍夫曼树。

* 赫夫曼树是带权路径长度最短的树，权值较大的结点离根较近。

* 路径和路径长度：在一棵树中，从一个结点往下可以达到的孩子或孙子结点之间的通路，称为路径。通路中分支的数目称为路径长度。若规定根结点的层数为1，则从根结点到第L层结点的路径长度为L-1

* 结点的权及带权路径长度：若将树中结点赋给一个有着某种含义的数值，则这个数值称为该结点的权。结点的带权路径长度为：从根结点到该结点之间的路径长度与该结点的权的乘积

* 树的带权路径长度：树的带权路径长度规定为所有叶子结点的带权路径长度之和，记为WPL(weighted path length) ,权值越大的结点离根结点越近的二叉树才是最优二叉树。

* WPL最小的就是赫夫曼树

#### 如下图

![image.png](https://img.hacpai.com/file/2019/09/image-04b3c07d.png)


#### 如何生存赫夫曼树

构成赫夫曼树的步骤：
1. 从小到大进行排序, 将每一个数据，每个数据都是一个节点 ， 每个节点可以看成是一颗最简单的二叉树
2. 取出根节点权值最小的两颗二叉树 
3. 组成一颗新的二叉树, 该新的二叉树的根节点的权值是前面两颗二叉树根节点权值的和  
4. 再将这颗新的二叉树，以根节点的权值大小 再次排序， 不断重复  1-2-3-4 的步骤，直到数列中，所有的数据都被处理，就得到一颗赫夫曼树

文字叙述可能太抽象，下面我们来看看图解

#### 准备一个数列{13, 7, 8, 3, 29, 6, 1}，数列里的值我们可以看成一个结点

我们先对其进行排序{1, 3, 6, 7, 8, 13, 29} 

之后我们可以看到这是一个有序数列，此时我们取出第一小的节点和第二小的节点然后生成一个父节点值为两个节点的值相加，并将其left与right拼接

![image.png](https://img.hacpai.com/file/2019/09/image-c71ef6bf.png)

之后从数列中删除1和3，并把4放入数列中

此时我们再进行排序，然后取出4和6继续重复上述操作,此时的数列为{7,8,10,13,29}

![image.png](https://img.hacpai.com/file/2019/09/image-d88026fb.png)

如法炮制 > 

![image.png](https://img.hacpai.com/file/2019/09/image-cef9f00b.png)

![image.png](https://img.hacpai.com/file/2019/09/image-fff39f10.png)

![image.png](https://img.hacpai.com/file/2019/09/image-12fbf724.png)

**最后变成了一颗赫夫曼树**

![image.png](https://img.hacpai.com/file/2019/09/image-f23109a0.png)

#### 代码实现

```
/**
 * 赫夫曼树
 * @Description
 * @Date 2019/9/6 13:40
 * @Author Aaron
 */
public class HuffmanTreeDemo {
    public static void main(String[] args) {
        int arr[] = {13, 7, 8, 3, 29, 6, 1};
        Node root = HuffmanTree.createHuffmanTree(arr);
        HuffmanTree.preOrder(root);
    }

}

// 赫夫曼树
class HuffmanTree {
    private int arr[] = {};
    private static List<Node> huffmanList = new ArrayList<>();
    public HuffmanTree(int[] arr) {
        this.arr = arr;
    }

    /**
     * 将数组转为集合, 并排好序
     * @param arr
     * @return
     */
    private static List<Node> arrToList(int arr[]) {
        // 将数组中的元素放入集合中
        for (int i = 0; i < arr.length; i++) {
            huffmanList.add(new Node(arr[i]));
        }
        return huffmanList;
    }

    /**
     * 创建一个赫夫曼树，即将数组转为对应的赫夫曼树
     * @param arr
     * @return
     */
    public static Node createHuffmanTree(int arr[]) {
        List<Node> nodes = arrToList(arr);

        while (nodes.size() > 1) {
            // 因为我们是升序排列
            Collections.sort(huffmanList);
            // 每次都取出排序后的最小节点和第二小节点进行比较
            Node leftNode = nodes.get(0);
            Node rightNode = nodes.get(1);
            Node parent = new Node(leftNode.val + rightNode.val);
            parent.left = leftNode;
            parent.right = rightNode;
            nodes.add(parent);
            // 每次添加新的节点后必须把原来两个节点给删除
            nodes.remove(leftNode);
            nodes.remove(rightNode);
        }
        return nodes.get(0);
    }

    // 前序遍历
    public static void preOrder(Node node) {
        if (node == null)return;
        System.out.println(node);
        if (node.left != null) {
            preOrder(node.left);
        }
        if (node.right != null) {
            preOrder(node.right);
        }
    }
}


class Node implements Comparable<Node>{
    int val;
    Node left;
    Node right;

    public Node(int val) {
        this.val = val;
    }

    @Override
    public String toString() {
        return "Node{" +
                "val=" + val +
                '}';
    }

    @Override
    public int compareTo(Node o) {
        return this.val - o.val;
    }
}

```






