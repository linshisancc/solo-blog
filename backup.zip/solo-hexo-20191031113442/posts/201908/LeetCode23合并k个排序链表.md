title: LeetCode 23 合并 k 个排序链表
date: '2019-08-27 22:55:03'
updated: '2019-08-27 23:04:42'
tags: [LeetCode心酸史]
permalink: /articles/2019/08/27/156688815830012.html
---
![](https://img.hacpai.com/bing/20190414.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 题目描述

合并 *k* 个排序链表，返回合并后的排序链表。请分析和描述算法的复杂度。

**要求:**

```
输入: [ 
1->4->5, 
1->3->4, 
2->6 
] 
输出: 1->1->2->3->4->4->5->6
```

#### 方法一：贪心算法, 优先队列

1、由于是 kk 个排序链表，那么这 kk 个排序的链表**头结点**中 `val` **最小**的结点就是合并以后的链表中最小的结点；

2、最小结点所在的链表的头结点就要更新了，更新成最小结点的下一个结点（如果有的话），此时还是这 kk 个链表，这 kk 个排序的链表头结点中 val 最小的结点就是合并以后的链表中第 22 小的结点。

写到这里，我想你应该差不多明白了，我们每一次都从这 kk 个排序的链表头结点中拿出 val 最小的结点“穿针引线”成新的链表，这个链表就是题目要求的“合并后的排序链表”。“局部最优，全局就最优”，这不就是贪心算法的思想吗。

#### 复杂度分析：

* 时间复杂度：`O(N \log k)O(Nlogk)`，这里 `NN` 是这 `kk` 个链表的结点总数，每一次从一个优先队列中选出一个最小结点的时间复杂度是 `O(\log k)O(logk)`，故时间复杂度为 `O(N \log k)O(Nlogk)`。

* 空间复杂度：`O(k)O(k)`，使用优先队列需要 `kk` 个空间，“穿针引线” 需要常数个空间，因此空间复杂度为 `O(k)O(k)`。


首先设计好链表
```
class ListNode {
     int val;
     ListNode next;
     
     public ListNode(int val) {
         this.val = val;
         this.next = null;
     }
}
```

```
public ListNode mergeKLists(ListNode[] lists) {      
        if (lists.length == 0 || null == lists) return null;
        // 单链表的问题，为了编码方便，经常需要设置一个虚拟头节点
        ListNode dummyNode = new ListNode(0);
        ListNode currentNode = dummyNode;
        //用heap(堆)这种数据结构，也就是 java 里面的 PriorityQueue
        PriorityQueue<ListNode> queue = new PriorityQueue<>(new Comparator<ListNode>() {
            public int compare(ListNode a, ListNode b) {
                return a.val - b.val;
            }
        });

        for(ListNode node: lists) {
            if(null != node) {
                queue.add(node);
            }
        }
        while(!queue.isEmpty()) {
            ListNode small = queue.poll();
            currentNode.next = small;
            currentNode = currentNode.next;
            if (small.next != null) {
                queue.add(small.next); // 将最小节点后面的节点添加到链表中
            }
        }
        return dummyNode.next;
    }
```

#### 方法二：分治法

其核心为递归， 分治

```
   public ListNode mergeKLists(ListNode[] lists) {  
	if (lists.length == 0) return null;
        return solve(lists, 0, lists.length - 1);
  }
  public ListNode solve(ListNode[] arr, int left, int right) {
        if (left == right) return arr[left];
        int mid = (left + right) >> 1;
        ListNode lNode = solve(arr, left, mid);
        ListNode rNode = solve(arr, mid + 1, right);
        return mergeTwoLists(lNode, rNode);
  }

    /**
     * 合并两个排序链表
     * @param node1
     * @param node2
     * @return
     */
    public ListNode mergeTwoLists(ListNode node1, ListNode node2) {
        if (node1 == null)
            return node2;
        if (node2 == null)
            return node1;

        ListNode head = null;

        if (node1.val < node2.val) {
            head = node1;
            head.next = mergeTwoLists(node1.next, node2);
        }else {
            head = node2;
            head.next = mergeTwoLists(node1, node2.next);
        }
        return head;
    }

```

#### 复杂度分析：

* 时间复杂度：`O(N \log k)O(Nlogk)`，这里 `NN` 是这 `kk` 个链表的结点总数，`kk` 个链表二分是对数级别的。
* 空间复杂度：（待讨论）合并两个排序链表需要“穿针引线”的指针数为常数，主要的空间消耗在递归方法上。

#### 模拟链表

```
	ListNode node1 = new ListNode(1);
        ListNode node2 = new ListNode(4);
        node1.next = node2;
        ListNode node3 = new ListNode(5);
        node2.next = node3;

        ListNode node4 = new ListNode(1);
        ListNode node5 = new ListNode(3);
        node4.next = node5;
        ListNode node6 = new ListNode(4);
        node5.next = node6;

        ListNode node7 = new ListNode(2);
        ListNode node8 = new ListNode(6);
        node7.next = node8;

        Solution solution = new Solution();
        ListNode listNode = solution.mergeKLists(new ListNode[]{node1, node4, node7});
        while (listNode != null) {
            System.out.println(listNode.val);
            listNode = listNode.next;
        }
```
如果看不太懂，请移步 [力扣算法解析](https://leetcode-cn.com/problems/merge-k-sorted-lists/solution/tan-xin-suan-fa-you-xian-dui-lie-fen-zhi-fa-python/)

第一次尝试链表算法题，花了一天时间消化，想到数据结构知识块不扎实，后续得补充，也给自己打个气，
争取能够有自己的思路写出算法推演的过程。


