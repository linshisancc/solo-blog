title: Java 算法 - QuictSort
date: '2019-09-03 17:13:55'
updated: '2019-09-03 17:13:55'
tags: [Java算法]
permalink: /articles/2019/09/03/1567502034973.html
---
![](https://img.hacpai.com/bing/20180830.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 快速排序法

快速排序（Quicksort）是对冒泡排序的一种改进。基本思想是：通过一趟排序将要排序的数据分割成独立的两部分，其中一部分的所有数据都比另外一部分的所有数据都要小，然后再按此方法对这两部分数据分别进行快速排序，整个排序过程可以递归进行，以此达到整个数据变成有序序列

#### 图解

![image.png](https://img.hacpai.com/file/2019/09/image-721e6fc3.png)

**代码实现**

```
/**
 * 快速排序
 * @Description TODO
 * @Date 2019/9/3  12:05
 * @Author Aaron
 */
public class QuickSort {
    public static void main(String[] args) {
        //int[] arr = {-9, 78, 0, 23, -567, 70};
        int[] arr = new int[8000000];
        SelectSort.getArr(arr);
        long start = System.currentTimeMillis();
        quickSort(arr, 0, arr.length - 1);
        long end = System.currentTimeMillis();
        System.out.printf("8000000个随机数使用快速排序所花费毫秒数为: %d 毫秒", end - start);
        //System.out.println(Arrays.toString(arr));
    }

    /**
     * 快速排序
     * @param arr
     * @param left
     * @param right
     */
    public static void quickSort(int[] arr, int left, int right) {
        int l = left;// 左下标
        int r = right;// 右下标
        int mid = arr[(left + right) / 2]; // 中间值
        int temp = 0;
        while (l < r) {
            // l 开始往右移动直到 arr[l] < mid 则退出循环
            while (arr[l] < mid) {
                l++; //
            }
            // r 开始往左移动直到 arr[r] > mid 则退出循环
            while (arr[r] > mid) {
                r--;
            }
            // 如果 l == r 说明 mid 左边的值已经小于 mid  而右边的值已经大于 mid
            if (l == r) break;
            // 开始交换
            temp = arr[l];
            arr[l] = arr[r];
            arr[r] = temp;
            if (arr[l] == mid) {
                r--;
            }
            if (arr[r] == mid) {
                l++;
            }
        }
        // 如果 l == r 必须 l++ r-- 否则出现栈溢出
        if (l == r) {
            l++;
            r--;
        }
        // 向左递归
        if (left < r) {
            quickSort(arr, left, r);
        }
        // 向右递归
        if (right > l) {
            quickSort(arr, l, right);
        }
    }
}
```
**测试800W个数据的排序所耗时间**

![image.png](https://img.hacpai.com/file/2019/09/image-a0fc44f8.png)

我们可以看到速度已经非常之快了😰 


