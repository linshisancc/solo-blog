title: Java 数据结构 - stack
date: '2019-08-31 15:35:26'
updated: '2019-09-01 16:48:13'
tags: [Java数据结构]
permalink: /articles/2019/08/31/1567236926713.html
---
# 栈的应用场景有那些
* 子程序的调用，在跳往子程序前，会将下个指令的地址存到栈堆中，直到子程序执行完后再将地址取出，以回到原来的程序中
* 处理递归调用，和子程序有点类似，只是除了存储下个指令的地址外，也将参数，区域变量等数据存入堆栈中
* 表达式的转换`[中缀表达式转后缀表达式]`与求值(实际解决)
* 二叉树的遍历
* 图形的深度优先(deep-first)搜索法

代码实现:

```
/**
 * 用单链表实现栈
 * @Description TODO
 * @Date 2019/8/31 0031 14:07
 * @Author Aaron
 */
public class LinkedListStackDemo {
    public static void main(String[] args) {
        LinkedListStack<Integer> linkedListStack = new LinkedListStack(5);
        linkedListStack.push(1);
        linkedListStack.push(2);
        linkedListStack.push(3);
        linkedListStack.push(4);
        linkedListStack.push(5);
        linkedListStack.pop();
        linkedListStack.list();
//        linkedListStack.list();
        //System.out.println(linkedListStack.isEmpty());
       /* linkedListStack.list();
        linkedListStack.pop();
        linkedListStack.pop();
        linkedListStack.pop();
        linkedListStack.pop();
        System.out.println("#########################");
        linkedListStack.list();
        System.out.println("########################");
        linkedListStack.push(5);
        linkedListStack.push(6);
        linkedListStack.push(7);
        linkedListStack.push(8);
        linkedListStack.list();
        Object peek = linkedListStack.peek();
        System.out.println(peek);*/

    }
}

class LinkedListStack<T> {
    // 创建一个头节点
    private StackNode<T> head;
    private int maxCapacity;// 最大栈容量
    private int count; // 入栈的个数
    private StackNode<T> top;


    public LinkedListStack(int maxCapacity) {
        this.head = new StackNode(-1);
        this.maxCapacity = maxCapacity;
    }

    // 判断栈是否为空
    public boolean isEmpty() {
        return count == 0;
    }

    public void list() {
        if (isEmpty()) throw new RuntimeException("the stack is empty");
        reverseList(head.next);
    }

    // 出栈
    public T pop() {
        if (isEmpty()) throw new RuntimeException("the stack is empty");
        StackNode<T> temp = head.next;
        T val = top.val;// 获取栈顶的值
        count--;
        //  移动到当前栈顶的前一位置 直接将next 赋值为null 即出栈
        while (true) {
            if (temp == top) {
                // 当 top 指向 head.next 时,栈内只有一个有效元素，只需要把 head.next = null 即可
                head.next = null;
                break;
            }
            if (temp.next == top) {
                temp.next = null;
                top = temp;
                break;
            }

            temp = temp.next;
        }

        return val;
    }

    public int Size() {
        return count;
    }

    /**
     * 使用逆序输出链表 模拟打印栈内容
     * @param stackNode
     */
    public void reverseList(StackNode stackNode) {
        if (stackNode == null) return ;
        reverseList(stackNode.next);
        System.out.printf("val = %d \n", stackNode.val);

    }

    public T peek() {
        if (isEmpty()) throw new RuntimeException("the stack is empty");
        return (T) top.val;
    }



    public boolean isFull() {
        return count == maxCapacity;
    }
    // 入栈
    public void push(Object val) {
        if (isFull()) throw new RuntimeException("the stack is full");
        StackNode cur = new StackNode(val);
        StackNode temp = head;
        while (true) {
            if (temp.next == null) {
                // 到达链表尾部
                temp.next = cur;
                // 移动top指针指向栈顶
                top = temp.next;
                count++;
                break;
            }
            temp = temp.next;
        }
    }
}

// 创建节点
class StackNode<T> {
    public T val;
    public StackNode next;

    public StackNode(T val) {
        this.val = val;
    }


}
```
