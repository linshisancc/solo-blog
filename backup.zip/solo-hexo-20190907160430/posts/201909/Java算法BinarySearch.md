title: Java 算法 - BinarySearch
date: '2019-09-04 12:57:28'
updated: '2019-09-04 12:57:28'
tags: [Java算法]
permalink: /articles/2019/09/04/1567573048715.html
---
## 二分法查找

因为二分法比较简单, 就不在多说什么, 所以我就直接上代码了

```
/**
 * 二分法查找
 * @Description TODO
 * @Date 2019/9/4 9:44
 * @Author Aaron
 */
public class BinarySearch {
    public static void main(String[] args) {
        int arr[] = {1, 8, 10, 89, 1000, 1000, 1000, 1234};
        ArrayList<Integer> list = binarySearch2(arr, 0, arr.length - 1, 1000);
        System.out.println(list);
    }

    /**
     * 二分法查找注意事项 该数组必须是一个有序数组
     * @param arr 需要查找的目标数组
     * @param left 左下标
     * @param right 右下标
     * @param findVal 待查找的值
     * @Return 如果找到则返回对应的下标 否则返回 -1
     */
    public static int binarySearch(int arr[], int left, int right, int findVal) {
        if (arr.length <= 0 || null == arr) throw new RuntimeException("the array is empty");
        if (left > right) return -1;
        int mid = (left + right) >> 1;
        if (arr[mid] < findVal) {
            // 如果需要查找的值比 arr[mid] 大则向右递归查找
            return binarySearch(arr, mid + 1, right, findVal);
        }else if (arr[mid] > findVal) {
            return binarySearch(arr, left, mid - 1, findVal);
        }else {
            return mid;
        }
    }

    /**
     * 将找到的多个值的下标放入集合中并返回
     * @param arr 需要查找的目标数组需要查找的目标数组
     * @param left 左下标
     * @param right 右下标
     * @param findVal 待查找的值
     * @return 返回list为空则没有找到 反之找到
     */
    public static ArrayList<Integer> binarySearch2(int arr[], int left, int right, int findVal) {
        if (arr.length <= 0 || null == arr) throw new RuntimeException("the array is empty");
        if (left > right) return new ArrayList<>();
        int mid = (left + right) >> 1;
        if (arr[mid] < findVal) {
            // 如果需要查找的值比 arr[mid] 大则向右递归查找
            return binarySearch2(arr, mid + 1, right, findVal);
        }else if (arr[mid] > findVal) {
            // 如果需要查找的值比 arr[mid] 小则向左递归查找
            return binarySearch2(arr, left, mid - 1, findVal);
        }else {
            // 如果 arr[mid] == findVal
            // 此时我们需要向该下标的左右分别进行扫描看是否有相同的值,如果有则加入集合中
            ArrayList<Integer> list = new ArrayList<>();
            int tempLeft = mid - 1;
            while (tempLeft > 0) {
                // 往左扫描
                if (arr[tempLeft] == findVal) {
                    list.add(tempLeft);
                }
                tempLeft--;
            }
            // 不要忘记吧mid也加进去
            list.add(mid);

            int tempRight = mid + 1;
            while (tempRight < arr.length - 1) {
                // 往右扫描
                if (arr[tempRight] == findVal) {
                    list.add(tempRight);
                }
                tempRight++;
            }
            return list;
        }
    }
}
```

