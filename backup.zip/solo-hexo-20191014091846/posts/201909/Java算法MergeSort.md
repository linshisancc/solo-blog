title: Java 算法 - MergeSort
date: '2019-09-03 17:23:46'
updated: '2019-09-03 17:23:46'
tags: [Java算法]
permalink: /articles/2019/09/03/1567502626264.html
---
![](https://img.hacpai.com/bing/20190311.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 归并排序

归并排序（MERGE-SORT）是利用归并的思想实现的排序方法，该算法采用经典的分治（divide-and-conquer）策略（分治法将问题分(divide)成一些小的问题然后递归求解，而治(conquer)的阶段则将分的阶段得到的各答案"修补"在一起，即分而治之)。

**图例**

![image.png](https://img.hacpai.com/file/2019/09/image-68d50d65.png)


我们可以看到这种结构很像一棵完全二叉树，这里的归并排序我们采用递归去实现（也可采用迭代的方式去实现）。分阶段可以理解为就是递归拆分子序列的过程。

#### 合并相邻有序子序列

我们需要将两个已经有序的子序列合并成一个有序序列，比如上图中的最后一次合并，要将[4,5,7,8]和[1,2,3,6]两个已经有序的子序列，合并为最终序列[1,2,3,4,5,6,7,8]，如下图所示

![image.png](https://img.hacpai.com/file/2019/09/image-2a053742.png)


![image.png](https://img.hacpai.com/file/2019/09/image-7b44f45f.png)


**代码实现**

```
/**
 * 归并排序
 * @Description TODO
 * @Date 2019/9/3 16:07
 * @Author Aaron
 */
public class MergeSort {
    public static void main(String[] args) {
        //int arr[] = {8, 4, 5, 7, 1, 3, 6, 2};
        int arr[] = new int[8000000];
        SelectSort.getArr(arr);
        long start = System.currentTimeMillis();
        mergeSort(arr, 0, arr.length - 1, new int[arr.length]);
        long end = System.currentTimeMillis();
        System.out.printf("8000000个随机数使用归并排序所花费毫秒数为: %d 毫秒", end - start);
        //System.out.println(Arrays.toString(arr));
    }

    /**
     * 归并排序
     * @param arr
     * @param left
     * @param right
     * @param temp
     */
    public static void mergeSort(int arr[], int left, int right, int temp[]) {
        if (left < right) {
            int mid = (left + right) / 2;
            // 左边开始递归分解
            mergeSort(arr, left, mid, temp);
            // 右边开始分解递归
            mergeSort(arr, mid + 1, right, temp);
            // 开始合并
            merge(arr, left, right, mid, temp);
        }
    }

    /**
     * 合并的方法
     * @param arr 待排序的数组
     * @param left 左边有序列表的下标
     * @param right 右边有序列表的下标
     * @param mid 中间下标
     * @param temp
     */
    public static void merge(int arr[], int left, int right, int mid, int temp[]) {
        int l = left; // 左边有序列表的初始下标
        int r = mid + 1; // 右边有序列表的初始下标
        int index = 0; // temp 数组的下标

        // 先吧左右两边(有序)的数据按照大小依次放入temp数组中
        while (l <= mid && r <= right) {
            if (arr[l] <= arr[r]) {
                // 如果左边的值比右边小或者等于则左边放入temp中 并让 l++ index++
                temp[index++] = arr[l++];
            } else {
                // 否则将右边的值放入temp中r++ index++
                temp[index++] = arr[r++];
            }
        }

        // 把有剩余数据的一边的数据依次放入temp中
        while (l <= mid) {
            // 说明左边有序列表还有剩余的元素，此时将其放入temp中同时 index 与 l 自增
            temp[index++] = arr[l++];
        }
        while (r <= right) {
            // 说明右边有序列表还有剩余的元素，此时将其放入temp中同时 index 与 r 自增
            temp[index++] = arr[r++];
        }

        // 将temp数组里的元素拷贝到arr中
        index = 0;
        int tempLeft = left;
        // 第一次合并 tempLeft = 0, right = 1
        // 第二次合并 tempLeft = 2, right = 3
        // 第三次合并 tempLeft = 0, right = 3
        // 最后一次合并 tempLeft = 0, right = 7
        //System.out.printf("tempLeft = %d, right = %d\n", tempLeft, right);
        while (tempLeft <= right) {
            arr[tempLeft++] = temp[index++];
        }

    }
}
```

#### 同时我们也来测一测其速度看是否比快排速度要快

![image.png](https://img.hacpai.com/file/2019/09/image-15f2044a.png)

他的速度已经接近于快排了😰 

