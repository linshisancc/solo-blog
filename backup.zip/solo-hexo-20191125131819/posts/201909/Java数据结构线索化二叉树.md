title: Java 数据结构 - 线索化二叉树
date: '2019-09-05 18:55:56'
updated: '2019-09-05 18:58:14'
tags: [Java数据结构]
permalink: /articles/2019/09/05/1567680956494.html
---
![](https://img.hacpai.com/bing/20190513.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



## 线索化二叉树

* n个结点的二叉链表中含有n+1  【公式 2n-(n-1)=n+1】 个空指针域。利用二叉链表中的空指针域，存放指向该结点在某种遍历次序下的前驱和后继结点的指针（这种附加的指针称为"线索"）
* 这种加上了线索的二叉链表称为线索链表，相应的二叉树称为线索二叉树(Threaded BinaryTree)。根据线索性质的不同，线索二叉树可分为前序线索二叉树、中序线索二叉树和后序线索二叉树三种
* 一个结点的前一个结点，称为前驱结点
* 一个结点的后一个结点，称为后继结点

将下面的二叉树，进行中序线索二叉树。中序遍历的数列为 {8, 3, 10, 1, 14, 6}

![image.png](https://img.hacpai.com/file/2019/09/image-8f29dc4a.png)

![image.png](https://img.hacpai.com/file/2019/09/image-0cf6c333.png)

**当线索化二叉树后，Node节点的 属性 left 和 right ，有如下情况**

* left 指向的是左子树，也可能是指向的前驱节点. 比如 ① 节点 left 指向的左子树, 而 ⑩ 节点的 left 指向的就是前驱节点.
* right指向的是右子树，也可能是指向后继节点，比如 ① 节点right 指向的是右子树，而⑩ 节点的right 指向的是后继节点.

**总共有三种线索化二叉树，其遍历方式也有三种，**
1. 前序线索化二叉树遍历相对最容易理解，实现起来也比较简单。由于前序遍历的顺序是：根左右，所以从根节点开始，沿着左子树进行处理，当子节点的left指针类型是线索时，说明到了最左子节点，然后处理子节点的right指针指向的节点，可能是右子树，也可能是后继节点，无论是哪种类型继续按照上面的方式（先沿着左子树处理，找到子树的最左子节点，然后处理right指针指向），以此类推，直到节点的right指针为空，说明是最后一个，遍历完成。
2. 中序遍历的顺序是：左根右，因此第一个节点一定是最左子节点，先找到最左子节点，依次沿着right指针指向进行处理（无论是指向子节点还是指向后继节点），直到节点的right指针为空，说明是最后一个，遍历完成
3. 后序遍历线索化二叉树比较复杂，这里先暂时不谈。。

**代码实现**

```
/**
 * 线索化二叉树
 * @Description TODO
 * @Date 2019/9/5 14:19
 * @Author Aaron
 */
public class ThreadBinaryTreeDemo {
    public static void main(String[] args) {
        ThreadBinaryTree binaryTree = new ThreadBinaryTree();
        TreeNode root = new TreeNode(1, "张三");
        TreeNode node2 = new TreeNode(3, "李四");
        TreeNode node3 = new TreeNode(6, "王五");
        TreeNode node4 = new TreeNode(8, "李白");
        TreeNode node5 = new TreeNode(10, "小红");
        TreeNode node6 = new TreeNode(14, "小白");
        binaryTree.setRoot(root);
        root.setLeft(node2);
        root.setRight(node3);
        node2.setLeft(node4);
        node2.setRight(node5);
        node3.setLeft(node6);
        // 中序遍历
        //binaryTree.midThread();
        //binaryTree.midThreadList();
        //binaryTree.preThreadNodes();
        //binaryTree.preThreadList();
        //System.out.println(node5.getLeft());
        //System.out.println(node5.getRight());
        //System.out.println(node6.getLeft());
        //System.out.println(node3.getRight().getRightType());
        binaryTree.postThreadNodes();
        //System.out.println(node3.getLeft());
        //System.out.println(node3.getRight());
        binaryTree.postThreadList();
    }
}

class ThreadBinaryTree {
    private TreeNode root;
    private TreeNode pre = null;

    public void setRoot(TreeNode root) {
        this.root = root;
    }


    public void midThread() {
        this.midThreadNodes(root);
    }
    public void preThreadNodes() {
        this.preThreadNodes(root);
    }
    public void postThreadNodes() {
        this.postThreadNodes(root);
    }

    // 前序遍历
    public void preThreadList() {
        if (root == null)return;
        TreeNode node = root;
        while (node != null) {
            while (node.getLeftType() == 0) {
                System.out.println(node);
                node = node.getLeft();
            }
            System.out.println(node);
            node = node.getRight();
        }

    }

    // 中序遍历
    public void midThreadList() {
        if (root == null)return;
        TreeNode node = root;
        while (node != null) {
            // 循环找到leftType = 1 的节点，第一个找到的就是8
            while (node.getLeftType() == 0) {
                node = node.getLeft();
            }
            // 打印当前这个节点
            System.out.println(node);
            // 如果当前节点的右指针指向的是后继结点，就一直输出
            while (node.getRightType() == 1) {
                node = node.getRight();
                System.out.println(node);
            }
            // 替换这个遍历的结点
            node = node.getRight();
        }
    }

    // 后序遍历
    public void postThreadList() {
        
    }

    // 后序线索化
    public void postThreadNodes(TreeNode treeNode) {
        if (null == treeNode) return;

        if (treeNode.getLeftType() == 0) {
            postThreadNodes(treeNode.getLeft());
        }

        if (treeNode.getRightType() == 0) {
            postThreadNodes(treeNode.getRight());
        }
        threadHandle(treeNode);
    }


    // 前序线索化
    public void preThreadNodes(TreeNode treeNode) {
        if (treeNode == null) return;

        threadHandle(treeNode);

        // 处理左子树
        if (treeNode.getLeftType() == 0) {
            preThreadNodes(treeNode.getLeft());
        }
        // 处理右子树
        if (treeNode.getRightType() == 0) {
            preThreadNodes(treeNode.getRight());
        }
    }



    // 处理线索化过程
    public void threadHandle(TreeNode treeNode) {
        // 线索化当前节点, 即处理当前节点的前驱节点
        // 如果当前节点的left为null，则让当前节点的left指向前驱节点pre，并将类型设置为1
        if (treeNode.getLeft() == null) {
            treeNode.setLeft(pre);
            treeNode.setLeftType(1);
        }
        // 处理后继节点就是让前一个节点的后继节点指向当前节点
        if (pre != null && pre.getRight() == null) {
            pre.setRight(treeNode);
            pre.setRightType(1);
        }
        // 每处理一个节点，就让当前节点变为下一个节点的前驱节点
        pre = treeNode;
    }

    // 中序线索化
    public void midThreadNodes(TreeNode treeNode) {
        if (treeNode == null) return;
        // 先线索化左子树
        midThreadNodes(treeNode.getLeft());

        // 处理线索化
        threadHandle(treeNode);

        // 再线索化右子树
        midThreadNodes(treeNode.getRight());
    }
}


/**
 * 树节点
 */
class TreeNode {
    private int id;
    private String name;
    private TreeNode left;
    private TreeNode right;
    private int LeftType;// 0 表示左子节点 1 表示前驱节点
    private int RightType;// 0 表示右子节点 1 表示后继节点

    public int getLeftType() {
        return LeftType;
    }

    public void setLeftType(int leftType) {
        LeftType = leftType;
    }

    public int getRightType() {
        return RightType;
    }

    public void setRightType(int rightType) {
        RightType = rightType;
    }

    public TreeNode(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TreeNode getLeft() {
        return left;
    }

    public void setLeft(TreeNode left) {
        this.left = left;
    }

    public TreeNode getRight() {
        return right;
    }

    public void setRight(TreeNode right) {
        this.right = right;
    }

    @Override
    public String toString() {
        return "TreeNode{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}

```
**小结**
学习树结构是越来越难了，一个知识点可能要一天时间去消化，理解，吸收，但是贵在坚持，不忘初心
😰  加油 ！
