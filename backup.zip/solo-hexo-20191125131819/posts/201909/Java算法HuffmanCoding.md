title: Java 算法 - Huffman Coding
date: '2019-09-07 15:17:28'
updated: '2019-09-07 17:43:47'
tags: [Java算法]
permalink: /articles/2019/09/07/1567840648234.html
---
![](https://img.hacpai.com/bing/20181123.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 赫夫曼编码

### 基本介绍

* 赫夫曼编码也翻译为    哈夫曼编码(Huffman Coding)，又称霍夫曼编码，是一种编码方式, 属于一种程序算法
* 赫夫曼编码是赫哈夫曼树在电讯通信中的经典的应用之一。
* 赫夫曼编码广泛地用于数据文件压缩。其压缩率通常在20%～90%之间
* 赫夫曼码是可变字长编码(VLC)的一种。Huffman于1952年提出一种编码方法，称之为最佳编码

### 原理剖析

#### 通信领域中信息的处理方式1-定长编码 
* 给定一个字符串`i like like like java do you like a java` 一共含有40个字符(包括空格)
* 其中每个字符对应的Ascii码为 105 32 108 105 107 101 32 108 105 107 101 32 108 105 107 101 32 106 97 118 97 32 100 111 32 121 111 117 32 108 105 107 101 32 97 32 106 97 118 97
* 对应的二进制为 01101001 00100000 01101100 01101001 01101011 01100101 00100000 01101100 01101001 01101011 01100101 00100000 01101100 01101001 01101011 01100101 00100000 01101010 01100001 01110110 01100001 00100000 01100100 01101111 00100000 01111001 01101111 01110101 00100000 01101100 01101001 01101011 01100101 00100000 01100001 00100000 01101010 01100001 01110110 01100001
* 我们可以看出其二进制的的总长度为 359(包括空格)

#### 通信领域中信息的处理方式2-变长编码
* 给定一个字符串`i like like like java do you like a java` 一共含有40个字符(包括空格) 
* d:1 y:1 u:1 j:2  v:2  o:2  l:4  k:4  e:4 i:5  a:5   :9(空格) 这里表示各个字符对应的次数
* 0=  ,  1=a, 10=i, 11=e, 100=k, 101=l, 110=o, 111=v, 1000=j, 1001=u, 1010=y, 1011=d
* 从上我们可以看出规律，各个字符按照出现的次数进行编码，原则是出现次数越多的，则编码越小，比如 空格出现了6 次， 编码为0 ,其它依次类推.
* 按照上面给各个字符规定的编码，则我们在传输  "i like like like java do you like a java" 数据时，编码就是10010..
* 字符的编码都不能是其他字符编码的前缀，符合此要求的编码叫做前缀编码

#### 通信领域中信息的处理方式3-赫夫曼编码
*  给定一个字符串`i like like like java do you like a java` 一共含有40个字符(包括空格) 
*  d:1 y:1 u:1 j:2  v:2  o:2  l:4  k:4  e:4 i:5  a:5   :9(空格) 这里表示各个字符对应的次数
* 按照上面字符出现的次数构建一颗赫夫曼树, 次数作为权值.(图后)
* ![image.png](https://img.hacpai.com/file/2019/09/image-e08e0890.png)

**根据赫夫曼编码，给各个字符进行编码规定，左路径为0右路径为1**

>**便得到如下** 
o: 1000   u: 10010  d: 100110  y: 100111  i: 101
a : 110     k: 1110    e: 1111       j: 0000       v: 0001
l: 001          : 01

按照上面的赫夫曼编码，我们的"i like like like java do you like a java"   字符串对应的编码为
1010100110111101111010011011110111101001101111011110100001100001110011001111000011001111000100100100110111101111011100100001100001110

其总长度为133, 而原来长度为359，压缩了  (359-133) / 359 = 62.9%，而且此编码满足前缀编码，即字符的编码都不能是其他字符编码的前缀，不会造成匹配的多义性，赫夫曼编码恰好就满足这一点。

### 注意

注意, 这个赫夫曼树根据排序方法不同，也可能不太一样，这样对应的赫夫曼编码也不完全一样，但是wpl 是一样的，都是最小的, 比如: 如果我们让每次生成的新的二叉树总是排在权值相同的二叉树的最后一个，则生成的二叉树为:

![image.png](https://img.hacpai.com/file/2019/09/image-5be9bc66.png)


#### 下面我们来测试压缩文件

**源文件** 

![image.png](https://img.hacpai.com/file/2019/09/image-07bdb4ec.png)

**压缩后** 
![image.png](https://img.hacpai.com/file/2019/09/image-c232616b.png)

**解压后**
![image.png](https://img.hacpai.com/file/2019/09/image-5dbeee63.png)

#### 并且文件没有损坏，还是可以用的

### 注意事项
如果文件本身就是经过压缩处理的，那么使用赫夫曼编码再压缩效率不会有明显变化, 比如视频,ppt 等等文件  [举例压一个 .ppt]
赫夫曼编码是按字节来处理的，因此可以处理所有的文件(二进制文件、文本文件) [举例压一个.xml文件]
如果一个文件中的内容，重复的数据不多，压缩效果也不会很明显



### 代码实现

```
/**
 * 赫夫曼编码
 * @Description
 * @Date 2019/9/6 20:50
 * @Author Aaron
 */
public class HuffmanCode {

    public static void main(String[] args) throws IOException {
        
        /*       
        String str = "i love you love you very much";
        byte[] zip = zip(str.getBytes());
        double originalLen = str.length();
        System.out.println("压缩前的字符串为" + str);
        System.out.println("压缩前的字节数组为:" + Arrays.toString(str.getBytes()));
        double curLen = new String(zip).length();
        System.out.println("压缩后的字符串为:" + new String(zip));
        System.out.println("压缩后的字节数组为:" + Arrays.toString(zip));
        System.out.println("压缩率为" + (originalLen - curLen) / originalLen);
        System.out.println("##################");
        byte[] unZip = deCode(zip);
        System.out.println("恢复压缩后的字符串为" + new String(unZip));
        */

        // 测试压缩文件
        zipFile("D:\\demo.png", "D:\\demo.zip");
        
        // 测试解压文件
        //unZip("D:\\demo.zip", "D:\\test2.png");
    }

    static StringBuilder stringBuilder1 = new StringBuilder();
    // 存放赫夫曼编码
    static HashMap<Byte,String> huffmanCode = new HashMap<>();


    /**
     * 压缩文件
     * @param src 源文件
     * @param dst 目标文件
     */
    public static void zipFile(String src, String dst) throws IOException {
        if (src == null || src.length() <= 0 || dst == null || dst.length() <= 0) return;
        File srcFile = new File(src);
        if (srcFile == null) throw new RuntimeException("源文件不存在！");
        FileInputStream is = null;
        ObjectOutputStream oos = null;
        try {
            is = new FileInputStream(srcFile);
            byte bytes[] = new byte[is.available()];
            // 将源文件读到bytes数组中
            is.read(bytes);
            byte[] huffmanBytes = zip(bytes);
            oos = new ObjectOutputStream(new FileOutputStream(dst));
            // 将赫夫曼编码字节数组写入文件中
            oos.writeObject(huffmanBytes);
            // 将赫夫曼编码写入文件中
            oos.writeObject(huffmanCode);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
               is.close();
               oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 解压文件
     * @param src 源文件
     * @param dst 目标文件
     */
    public static void unZip(String src, String dst) {
        if (src == null || src.length() <= 0 || dst == null || dst.length() <= 0) return;
        File srcFile = new File(src);
        if (srcFile == null) throw new RuntimeException("源文件不存在");
        ObjectInputStream os = null;
        FileOutputStream fos = null;
        try {
            os = new ObjectInputStream(new FileInputStream(srcFile));
            // 读取赫夫曼字节数组
            byte huffmanBytes[] = (byte[]) os.readObject();
            // 读取赫夫曼编码
            Map<Byte, String> huffmanCode = (Map<Byte, String>) os.readObject();
            byte[] b = deCode(huffmanBytes, huffmanCode);
            fos = new FileOutputStream(dst);
            fos.write(b);
        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                os.close();
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }



    /**
     * 将目标字符串的字符进行统计次数
     * 生成对应的字符加出现次数 比如 i : 1  o : 2 这种形式存放到node节点里然后放入集合中
     * 这里字符出现的次数就表示树结构里的权值，字符则为存储的值
     * @param bytes
     * @return 返回一个node的集合list
     */
    public static List<Node> countNum(byte bytes[]) {
        if (bytes == null || bytes.length <= 0) return null;
        Map<Byte, Integer> map = new HashMap<>();
        List<Node> list = new ArrayList<>();
        for (byte item : bytes) {
            Integer integer = map.get(item);
            if (integer == null) {
                map.put(item, 1);
            }else {
                map.put(item, ++integer);
            }
        }
        for (Map.Entry<Byte, Integer> entry : map.entrySet()) {
            list.add(new Node(entry.getKey(), entry.getValue()));
        }
        return list;
    }

    // 重载生成赫夫曼编码
    private static Map<Byte, String> createHuffmanCode(Node node) {
        if (node == null) return null;
        createHuffmanCode(node.left, "0", stringBuilder1);
        createHuffmanCode(node.right, "1", stringBuilder1);
        return huffmanCode;
    }




    // 重载压缩方法
    public static byte[] zip(byte bytes[]) {
        if (bytes == null || bytes.length <= 0) return null;
        List<Node> nodes = countNum(bytes);
        Node huffmanTree = createHuffmanTree(nodes);
        Map<Byte, String> huffmanCode = createHuffmanCode(huffmanTree);
        return zip(bytes, huffmanCode);
    }

    /**
     * 将字符串对应的byte数组，通过生成的赫夫曼编码表，返回一个赫夫曼编码压缩后的byte数组
     * @param arr
     * @param huffmanCode
     */
    public static byte[] zip(byte arr[], Map<Byte, String> huffmanCode) {
        StringBuilder sb = new StringBuilder();
        // 将byte转为赫夫曼编码的字符串
        for (byte b : arr) {
            sb.append(huffmanCode.get(b));
        }

        int len = sb.length() % 8 == 0 ? sb.length() / 8 : sb.length() / 8 + 1;

        // 创建存储压缩后的byte数组
        byte[] store = new byte[len];
        int index = 0;
        String str = "";
        for (int i = 0; i < sb.length(); i += 8) {
            if (i + 8 > sb.length()) {
                str = sb.substring(i);
            }else {
                str = sb.substring(i, i + 8);
            }
            store[index++] = (byte) Integer.parseInt(str, 2);
        }
        return store;
    }

    // 重载解码方法
    public static byte[] deCode(byte[] huffmanBytes) {
        if (huffmanBytes == null || huffmanBytes.length <= 0) return null;
        return deCode(huffmanBytes, huffmanCode);
    }

    /**
     * @param huffmanBytes 赫夫曼编码得到后的字节数组
     * @param huffmanCode 赫夫曼编码
     * @return 原来字符串对应的字节数组
     */
    public static byte[] deCode(byte[] huffmanBytes, Map<Byte, String> huffmanCode) {
        StringBuilder stringBuilder = new StringBuilder();
        boolean flag = true;
        // 将huffmanBytes数组转为对应的二进制字符串
        for (int i = 0; i < huffmanBytes.length; i++) {
            // 判断是不是最后一个字节
            flag = (i == huffmanBytes.length - 1);
            stringBuilder.append(byteToBinaryString(!flag, huffmanBytes[i]));
        }

        // 将赫夫曼编码的存储形式改为String byte 形式存储比如 100 -> a
        Map<String, Byte> map = new HashMap<>();
        for (Map.Entry<Byte, String> huffmanEntry : huffmanCode.entrySet()) {
            map.put(huffmanEntry.getValue(), huffmanEntry.getKey());
        }

        Byte b = null;
        boolean isTrue;
        StringBuilder sb = new StringBuilder();
//        List<Byte> list = new ArrayList<>();
        for (int i = 0; i < stringBuilder.length(); ) {
            isTrue = true;
            int count = 1;
            // 开始匹配赫夫曼编码表
            while (isTrue) {
                // 101011111  逐渐递增的取,直到取出对应的一位字符 100 - a
                String str = stringBuilder.substring(i, i + count);
                b = map.get(str);
                if (b == null) {
                    count++;
                }else {
                    isTrue = false;
                }
            }
           // list.add(b);
            // 拼接字符,用逗号隔开
            sb.append(b);
            sb.append(",");
            i += count;
        }
        String[] split = sb.toString().split(",");
        byte bytes[] = new byte[split.length];
        for (int i = 0; i < split.length; i++) {
            int a = Integer.valueOf(split[i]);
            bytes[i] = (byte) a;
        }
        return bytes;
    }


    /**
     * 将一个字节转换为对应的二进制字符串(获得的是反码)
     * @param b 需要转换的字节
     * @param flag 为 true 表示
     * @return
     */
    private static String byteToBinaryString(boolean flag, byte b) {
        int temp = b;
        // 如果为正数，则需要补高位
        if (flag) {
            temp |= 256; // 按位或运算比如 256 | 1  -->  1 0000 0000 | 0000 0001 = 1 0000 0001
        }
        // 注意这里返回的是temp对应的二进制的反码 运算如下
        /**
         * 比如 byte 等于 -1 转为对应的二进制则为 1 0000 0001
         * 我们需要获得它的补码，先将其取反得 1 1111 1110 然后加上1就得到 1 1111 1111 此时我们需要截取的就是1111 1111
         */
        String byteStr = Integer.toBinaryString(temp);
        if (flag) {
            return byteStr.substring(byteStr.length() - 8);
        }else {
            // flag为时假表示最后一个byte不需要补高位,直接返回对应的字符串
            return byteStr;
        }
    }

    /**
     * 生成赫夫曼编码
     * @param node 需要处理的节点
     * @param code 路径 左 为 0 右为 1
     * @param stringBuilder 用于拼接路径
     */
    public static void createHuffmanCode(Node node, String code, StringBuilder stringBuilder) {
        StringBuilder stringBuilder2 = new StringBuilder(stringBuilder);
        stringBuilder2.append(code);
        if (node != null) {
            // 判断当前node是叶子节点还是非叶子节点
            if (node.val == null) {
                // 非叶子节点
                createHuffmanCode(node.left, "0", stringBuilder2);
                createHuffmanCode(node.right, "1", stringBuilder2);
            }else {
                // 叶子节点，放入map中
                huffmanCode.put(node.val, stringBuilder2.toString());
            }
        }
    }


    // 将目标树转成对应的赫夫曼树
    public static Node createHuffmanTree(List<Node> resource) {
        if (resource == null || resource.size() <= 0) return null;
        while (resource.size() > 1) {
            // 先进行排序
            Collections.sort(resource);
            // 取出最小的节点和第二小的节点
            Node nodeLeft = resource.get(0);
            Node nodeRight = resource.get(1);
            Node parent = new Node(null, nodeLeft.weighted + nodeRight.weighted);
            parent.left = nodeLeft;
            parent.right = nodeRight;
            resource.add(parent);
            resource.remove(nodeLeft);
            resource.remove(nodeRight);
        }
        return resource.get(0);
    }


    public static void preOrder(Node node) {
        if (node != null) {
            node.preOrder();
        }else {
            System.out.println("树为空，遍历失败");
        }
    }

}

class Node implements Comparable<Node>{
    public Byte val;
    public int weighted;// 权值
    public Node left;
    public Node right;

    // 前序遍历
    public void preOrder() {
        System.out.println(this);
        if (this.left != null) {
            this.left.preOrder();
        }
        if (this.right != null) {
            this.right.preOrder();
        }
    }

    public Node(int weighted) {
        this.weighted = weighted;
    }

    public int getWeighted() {
        return weighted;
    }

    public Node(Byte val, int weighted) {
        this.val = val;
        this.weighted = weighted;
    }

    @Override
    public String toString() {
        return "Node{" +
                "val=" + val +
                ", weighted=" + weighted +
                '}';
    }

    @Override
    public int compareTo(Node o) {
        return this.weighted - o.weighted;
    }
}
```


