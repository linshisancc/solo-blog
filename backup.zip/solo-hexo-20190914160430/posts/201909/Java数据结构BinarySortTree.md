title: Java 数据结构 - BinarySortTree
date: '2019-09-08 12:44:29'
updated: '2019-09-08 12:44:29'
tags: [Java数据结构]
permalink: /articles/2019/09/08/1567917869290.html
---
![](https://img.hacpai.com/bing/20181105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 二叉排序树
### 介绍
二叉排序树：BST: (Binary Sort(Search) Tree), 对于二叉排序树的任何一个非叶子节点，要求左子节点的值比当前节点的值小，右子节点的值比当前节点的值大。
特别说明：如果有相同的值，可以将该节点放在左子节点或右子节点

比如针对前面的数据 (7, 3, 10, 12, 5, 1, 9) ，对应的二叉排序树为：

![123123781267893.PNG](https://img.hacpai.com/file/2019/09/123123781267893-597d323b.PNG)

### 二叉排序树的遍历和创建

一个数组创建成对应的二叉排序树，并使用中序遍历二叉排序树，比如: 数组为 Array(7, 3, 10, 12, 5, 1, 9) ， 创建成对应的二叉排序树为 :

![image.png](https://img.hacpai.com/file/2019/09/image-80500acd.png)

### 对应实现代码
```
/**
     * 使用递归添加节节点，满足二叉排序树的要求
     * @param node
     */
    public void add(Node node) {
        if (node == null) return;

        // 判断当前传入的节点的值，和当前子树的根节点的值的关系
        if (this.val > node.val) {
            // 如果当前节点的左子节点为null
            if (this.left == null) {
                this.left = node;
            }else {
                this.left.add(node);
            }
        }else {
            // 表示添加的节点的值大于当前节点的值
            if (this.right == null) {
                this.right = node;
            }else {
                this.right.add(node);
            }
        }
    }
```

### 二叉排序树的删除

1. 删除叶子节点 (比如：2, 5, 9, 12)
2. 删除只有一颗子树的节点 (比如：1)
3. 删除有两颗子树的节点. (比如：7, 3，10 )

![image.png](https://img.hacpai.com/file/2019/09/image-5694afa5.png)

### 代码实现

### 先准备两个方法，一个用来查找节点，一个用来查找待查节点的父节点

### 查找结点
```
/**
     * 查找节点
     * @param val 待查找节点的值
     * @return 返回noll说明没有找到
     */
    public Node findNode(int val) {
        if (this.val == val) {
            return this;
        }
        else if (this.val > val) {
            // 如果要查找的节点小于当前节点，则向左子树递归查找
            // 如果左子节点为空则返回null
            if (this.left == null)return null;
            return this.left.findNode(val);
        }else {
            // 反之要查找的节点值大于或等于当前节点，则向右子树递归查找
            // 当右节点为空时，返回null
            if (this.right == null) return null;
            return this.right.findNode(val);
        }
    }
```
### 查找父节点

```
/**
     * 查找父节点
     * @param val 需要查找父节点的节点
     * @return 返回null说明没找到，反之则找到
     */
    public Node findParent(int val) {
        // 如果当前节点就是要查找的父节点,就直接返回
        if (this.left != null && this.left.val == val
                || this.right != null && this.right.val == val) {
            return this;
        }else {
            // 如果当前节点的值大于要查找的节点的值并且左子树不为空，则左递归查找其父节点
            if (this.val > val && this.left != null) {
                return this.left.findParent(val);
            }else if (this.val <= val && this.right != null){
             // 如果当前节点的值小于或等于要查找的节点的值并且右子树不为空，则右递归查找其父节点
                return this.right.findParent(val);
            }else {
                // 没有找到返回null
                return null;
            }
        }
    }
```

### 删除以当前结点为根节点的最大值结点
```
// 删除以node为根的子树中的最大节点
    public int delLeftTreeMax(Node node) {
        Node temp = node;
        // 往右查找最大节点
        while (temp.right != null) {
            temp = temp.right;
        }
        delNode(temp.val);
        // 返回最大节点的值
        return temp.val;
    }
```


### 删除结点的完整代码

```
/**
     * 删除节点
     * 1. 删除叶子节点 (比如：2, 5, 9, 12)
     * 2. 删除只有一颗子树的节点 (比如：1)
     * 3. 删除有两颗子树的节点. (比如：7, 3，10 )
     * @param val
     */
    public void delNode(int val) {
        if (root == null){
            return ;
        }else {
            Node node = root.findNode(val);
            if (node == null) {
                return ;
            }
            // 如果整个二叉排序树只有一个节点,则直接把root置空
            if (root.left == null && root.right == null) {
                root = null;
                return ;
            }

            // 查找父节点
            Node parent = findParent(val);
            if (node.left == null && node.right == null) {
                // 删除的结点为叶子节点
                // 判断需要删除的节点是其父节点的左子节点还是右子节点
                if (parent.left != null && parent.left.val == node.val) {
                    // 左子节点
                    parent.left = null;
                }else if (parent.right != null && parent.right.val == node.val) {
                    // 右子节点
                    parent.right = null;
                }
            }else if (node.left != null && node.right != null) {
                // 删除有两个子树的节点
                /**
                 * 比如删掉 node 7 ，我们先从它的左子数找出最大值，即node 5 将其删除，然后将node 5 的值赋给 node 7 满足二叉排序树
                 * 或者可以从右子树找出最小值，即 node 9，然后将其删除，再将node 9 的值赋给node 7 满足二叉排序树
                 */
                int max = delLeftTreeMax(node.left);
                // 将max替换node的值满足二叉排序树
                node.val = max;
            }else {
                // 删除有一颗子树的节点
                if (node.left != null) {
                    if (parent != null) {
                        // 如果要删除的节点只有左子节点
                        if (parent.left.val == val) {
                            // 如果node是parent的左子节点
                            parent.left = node.left;
                        }else {
                            // node是parent的右子节点
                            parent.right = node.left;
                        }
                    }else {
                        // 删除的节点为根节点并且只有一个左子节点时，我们直接让其左子节点成为根节点
                        root = node.left;
                    }

                }else {
                    if (parent != null) {
                        // 如果要删除的节点只有右子节点
                        if (parent.right.val == val) {
                            // node是parent的右子节点
                            parent.right = node.right;
                        }else {
                            // node是parent的左子节点
                            parent.left = node.right;
                        }
                    }else {
                        // 删除的节点为根节点并且只有一个右子节点时，我们直接让其右子节点成为根节点
                        root = node.right;
                    }
                }
            }
        }
    }
```

### 测试一轮后发现没有问题，自此，二叉排序树的增加与删除就已经实现

### 完整代码

```
/**
 * 二叉排序树
 * @Description TODO
 * @Date 2019/9/7 21:49
 * @Author Aaron
 */
public class BinarySortTreeDemo {
    public static void main(String[] args) {
        int arr[] = {7, 3, 10, 12, 5, 1, 9, 2};
        BinarySortTree binarySortTree = new BinarySortTree();
        for (int i : arr) {
            binarySortTree.add(new Node(i));
        }
        binarySortTree.infixOrder();
        // 删除一个叶子节点
        binarySortTree.delNode(2);
        // 删除一个有两颗子树的非叶子节点
        binarySortTree.delNode(7);
        // 删除一个有一颗子树的非叶子节点
        binarySortTree.delNode(1);

        System.out.println("根节点" + binarySortTree.getRoot());
        System.out.println("删除后###################");
        binarySortTree.infixOrder();

    }
}

class BinarySortTree {
    public Node root;

    public Node getRoot() {
        return root;
    }

    // 中序遍历
    public void infixOrder() {
        if (root != null) {
            root.infixOrder();
        }else {
            System.out.println("树为空，遍历失败");
        }
    }

    public void add(Node node) {
        if (root == null) {
            root = node;
        }else {
            root.add(node);
        }
    }

    // 删除以node为根的子树中的最大节点
    public int delLeftTreeMax(Node node) {
        Node temp = node;
        // 往右查找最大节点
        while (temp.right != null) {
            temp = temp.right;
        }
        delNode(temp.val);
        // 返回最大节点的值
        return temp.val;
    }

    /**
     * 删除节点
     * 1. 删除叶子节点 (比如：2, 5, 9, 12)
     * 2. 删除只有一颗子树的节点 (比如：1)
     * 3. 删除有两颗子树的节点. (比如：7, 3，10 )
     * @param val
     */
    public void delNode(int val) {
        if (root == null){
            return ;
        }else {
            Node node = root.findNode(val);
            if (node == null) {
                return ;
            }
            // 如果整个二叉排序树只有一个节点,则直接把root置空
            if (root.left == null && root.right == null) {
                root = null;
                return ;
            }

            // 查找父节点
            Node parent = findParent(val);
            if (node.left == null && node.right == null) {
                // 删除的结点为叶子节点
                // 判断需要删除的节点是其父节点的左子节点还是右子节点
                if (parent.left != null && parent.left.val == node.val) {
                    // 左子节点
                    parent.left = null;
                }else if (parent.right != null && parent.right.val == node.val) {
                    // 右子节点
                    parent.right = null;
                }
            }else if (node.left != null && node.right != null) {
                // 删除有两个子树的节点
                /**
                 * 比如删掉 node 7 ，我们先从它的左子数找出最大值，即node 5 将其删除，然后将node 5 的值赋给 node 7 满足二叉排序树
                 * 或者可以从右子树找出最小值，即 node 9，然后将其删除，再将node 9 的值赋给node 7 满足二叉排序树
                 */
                int max = delLeftTreeMax(node.left);
                // 将max替换node的值满足二叉排序树
                node.val = max;
            }else {
                // 删除有一颗子树的节点
                if (node.left != null) {
                    if (parent != null) {
                        // 如果要删除的节点只有左子节点
                        if (parent.left.val == val) {
                            // 如果node是parent的左子节点
                            parent.left = node.left;
                        }else {
                            // node是parent的右子节点
                            parent.right = node.left;
                        }
                    }else {
                        // 删除的节点为根节点并且只有一个左子节点时，我们直接让其左子节点成为根节点
                        root = node.left;
                    }

                }else {
                    if (parent != null) {
                        // 如果要删除的节点只有右子节点
                        if (parent.right.val == val) {
                            // node是parent的右子节点
                            parent.right = node.right;
                        }else {
                            // node是parent的左子节点
                            parent.left = node.right;
                        }
                    }else {
                        // 删除的节点为根节点并且只有一个右子节点时，我们直接让其右子节点成为根节点
                        root = node.right;
                    }
                }
            }
        }
    }


    // 查找节点
    public Node findNode(int val) {
        if (root == null) {
            return null;
        }else {
            return root.findNode(val);
        }
    }

    // 查找父节点
    public Node findParent(int val) {
        if (root == null) {
            return null;
        }else {
            return root.findParent(val);
        }
    }
}

class Node {
    public int val;
    public Node left;
    public Node right;

    public Node(int val) {
        this.val = val;
    }

    @Override
    public String toString() {
        return "Node{" +
                "val=" + val +
                '}';
    }

    // 中序遍历
    public void infixOrder() {
        if (this.left != null) {
            this.left.infixOrder();
        }
        System.out.println(this);
        if (this.right != null) {
            this.right.infixOrder();
        }
    }


    /**
     * 查找父节点
     * @param val 需要查找父节点的节点
     * @return 返回null说明没找到，反之则找到
     */
    public Node findParent(int val) {
        // 如果当前节点就是要查找的父节点,就直接返回
        if (this.left != null && this.left.val == val
                || this.right != null && this.right.val == val) {
            return this;
        }else {
            // 如果当前节点的值大于要查找的节点的值并且左子树不为空，则左递归查找其父节点
            if (this.val > val && this.left != null) {
                return this.left.findParent(val);
            }else if (this.val <= val && this.right != null){
             // 如果当前节点的值小于或等于要查找的节点的值并且右子树不为空，则右递归查找其父节点
                return this.right.findParent(val);
            }else {
                // 没有找到返回null
                return null;
            }
        }
    }


    /**
     * 查找节点
     * @param val 待查找节点的值
     * @return 返回noll说明没有找到
     */
    public Node findNode(int val) {
        if (this.val == val) {
            return this;
        }
        else if (this.val > val) {
            // 如果要查找的节点小于当前节点，则向左子树递归查找
            // 如果左子节点为空则返回null
            if (this.left == null)return null;
            return this.left.findNode(val);
        }else {
            // 反之要查找的节点值大于或等于当前节点，则向右子树递归查找
            // 当右节点为空时，返回null
            if (this.right == null) return null;
            return this.right.findNode(val);
        }
    }


    /**
     * 使用递归添加节节点，满足二叉排序树的要求
     * @param node
     */
    public void add(Node node) {
        if (node == null) return;

        // 判断当前传入的节点的值，和当前子树的根节点的值的关系
        if (this.val > node.val) {
            // 如果当前节点的左子节点为null
            if (this.left == null) {
                this.left = node;
            }else {
                this.left.add(node);
            }
        }else {
            // 表示添加的节点的值大于当前节点的值
            if (this.right == null) {
                this.right = node;
            }else {
                this.right.add(node);
            }
        }
    }
}
```
