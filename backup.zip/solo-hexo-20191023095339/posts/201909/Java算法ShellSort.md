title: Java 算法 - ShellSort
date: '2019-09-03 11:27:44'
updated: '2019-09-03 11:28:07'
tags: [Java算法]
permalink: /articles/2019/09/03/1567481264624.html
---
![](https://img.hacpai.com/bing/20180830.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 希尔排序
希尔排序是希尔（Donald Shell）于1959年提出的一种排序算法。希尔排序也是一种插入排序，它是简单插入排序经过改进之后的一个更高效的版本，也称为缩小增量排序。

#### 思想
希尔排序是把记录按下标的一定增量分组，对每组使用直接插入排序算法排序；随着增量逐渐减少，每组包含的关键词越来越多，当增量减至1时，整个文件恰被分成一组，算法便终止

**图例**

![image.png](https://img.hacpai.com/file/2019/09/image-06e3f175.png)

很明显，我们能够看到的是通过一个增量将数组分为对应的组数，然后再进行直接插入排序，这样就不会出现较小数在后面的情况了。

#### 代码实现

```
/**
 * 希尔排序
 * @Description TODO
 * @Date 2019/9/3  9:53
 * @Author Aaron
 */
public class ShellSort {
    static int count = 0;
    public static void main(String[] args) {
        //int arr[] = {8, 9, 1, 7, 2, 3, 5, 4, 6, 0};
        int arr[] = new int[80000];
        SelectSort.getArr(arr);
        long start = System.currentTimeMillis();
        shellSort2(arr);
        long end = System.currentTimeMillis();
        System.out.printf("80000个随机数使用希尔排序所花费毫秒数为: %d 毫秒", end - start);
    }

    /**
     * 希尔排序(换位版)
     * @param arr
     */
    public static void shellSort1(int arr[]) {
        int temp = 0;
        for (int gap = arr.length / 2; gap > 0; gap /= 2) {
            for (int i = gap; i < arr.length; i++) {
                // 遍历各组中的元素共 gap 组 步长为 gap
                for (int j = i - gap; j >= 0; j -= gap) {
                    if (arr[j] > arr[j + gap]) { // 如果当前元素大于加上不长的那个元素说明需要交换位置
                        temp = arr[j];
                        arr[j] = arr[j + gap];
                        arr[j + gap] = temp;
                    }
                }
            }
            //System.out.printf("第%d组进行了交换", ++count);
            //System.out.println(Arrays.toString(arr));
        }
    }

    /**
     *
     * @param arr
     */
    public static void shellSort2(int arr[]) {
        if (null == arr || arr.length <= 0) throw new RuntimeException("the array is empty");
        int temp = 0;
        // gap 表示增量，并逐步缩小的增量
        for (int gap = arr.length / 2; gap > 0 ; gap /= 2) {
            // 从第 gap 个元素，逐个对其所在的组进行直接插入排序
            for (int i = gap; i < arr.length; i++) {
                int j = i;
                temp = arr[j];
               if (arr[j] < arr[j - gap]) {
                   while (j - gap >= 0 && temp < arr[j - gap]) {
                       // 移动
                       arr[j] = arr[j - gap];
                       j -= gap;
                   }
                   // 退出while后即给temp找到插入位置
                   arr[j] = temp;
               }
            }
            //System.out.printf("第%d组进行了交换", ++count);
            //System.out.println(Arrays.toString(arr));
        }
    }
}
```



**我们使用了两种方法来对希尔排序进行实现，一个是通过换位而另一种是通过移位**

我们来看看两者的时间差

#### 换位
![image.png](https://img.hacpai.com/file/2019/09/image-2bddb7a7.png)

#### 移位
![image.png](https://img.hacpai.com/file/2019/09/image-d1caf98b.png)

**惊呆了，这差距可不是一星半点，只能说算法的优化真厉害 😰** 


