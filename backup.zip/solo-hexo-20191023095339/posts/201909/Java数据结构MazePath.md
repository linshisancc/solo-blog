title: Java 数据结构-MazePath
date: '2019-09-02 15:34:17'
updated: '2019-09-02 15:35:56'
tags: [Java数据结构]
permalink: /articles/2019/09/02/1567409657700.html
---
![](https://img.hacpai.com/bing/20171210.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 迷宫问题(MazePath)

####  迷宫问题是典型的图的搜索问题

假设一个迷宫，只有一个入口和一个出口。如果从迷宫的入口到达出口，途中不出现行进方向错误，则得到一条最佳路线。

#### 我们可以使用回溯法来解决迷宫问题，那什么又是回溯法呢？

* **回溯法(backtracking)是一种选优搜索法，又称为试探法，按选优条件向前搜索，以达到目标。**

关于回溯法感兴趣的朋友们可以去搜索了解了解，下面我就直接上代码: 

```
/**
 * 迷宫问题
 * @Description TODO
 * @Date 2019/9/2 0002 10:54
 * @Author Aaron
 */
public class MazeProblem {
    public static void main(String[] args) {
        // 创建一个二维数组 8 行 7 列模拟迷宫
        int arr[][] = new int[8][7];
        // 将第一行和最后一行 第一列和最后一列设置为墙
        for (int i = 0; i < 8; i++) {
            arr[i][0] = 1;
            arr[i][6] = 1;
        }
        for (int i = 0; i < 7; i++) {
            arr[0][i] = 1;
            arr[7][i] = 1;
        }

        // 设置障碍物 这里我们将 1 表示障碍物 2 表示通路 3 表示探索过的死路
        arr[3][1] = 1;
        arr[3][2] = 1;
        arr[2][2] = 1;

        findWay(arr, 1, 1);
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 7; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }

    }

    /**
     * 探路 这里我们将 0 表示未走的路 1 表示障碍物 2 表示已走过的通路 3 表示探索过的死路
     * 这个过程我们可以指定规则 下 > 右 > 上 > 左
     * @param arr 操作的数组
     * @param row 行
     * @param col 列
     * @return
     */
    public static boolean findWay(int [][] arr, int row, int col) {
        if (arr[6][5] == 2) {
            return true; // 找到出口
        }else {
            if (arr[row][col] == 0) {
                // 假设其为通路,但不一定是通路，后面可能回溯
                arr[row][col] = 2;
                if (findWay(arr, row + 1, col))  return true; // 往下找
                else if (findWay(arr, row, col + 1)) return true; // 往右找
                else if (findWay(arr, row - 1, col)) return true; // 往上找
                else if (findWay(arr, row, col - 1)) return true; // 往左找
                else {
                    // 走不通 设置为死路
                    arr[row][col] = 3;
                    return false;
                }
            }else {
                // 可能为1,2,3
                return false;
            }
        }
    }
}

```
**我们打印出迷宫(1 表示障碍物， 0 表示探索路线)** 

![image.png](https://img.hacpai.com/file/2019/09/image-3db259cf.png)

再来看看结果

![image.png](https://img.hacpai.com/file/2019/09/image-b1c37de0.png)

此时我们可以发现当走到3时右下左都走不通，所以只能往上走并将路设置为死路然后继续遵循 下 - 右 - 上 - 左的规律继续前进。。





